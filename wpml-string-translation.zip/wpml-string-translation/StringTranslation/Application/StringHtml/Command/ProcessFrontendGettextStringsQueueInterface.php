<?php

namespace WPML\StringTranslation\Application\StringHtml\Command;

interface ProcessFrontendGettextStringsQueueInterface {
	public function run();
}