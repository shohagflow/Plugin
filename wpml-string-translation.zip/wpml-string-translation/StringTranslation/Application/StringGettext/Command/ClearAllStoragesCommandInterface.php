<?php

namespace WPML\StringTranslation\Application\StringGettext\Command;

interface ClearAllStoragesCommandInterface {
	public function run();
}