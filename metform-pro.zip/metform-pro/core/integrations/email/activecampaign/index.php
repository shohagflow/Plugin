<?php
// Take care of your life and the Lord will take care of your death