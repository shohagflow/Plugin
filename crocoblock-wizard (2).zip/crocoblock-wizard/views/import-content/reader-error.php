<div class="cbw-block cbw-connection-error">
	<div class="cbw-body__title"><?php
		_e( 'Oops!', 'crocoblock-wizard' );
	?></div>
	<div class="cbw-body__subtitle"><?php
		_e( 'XMLReader PHP extension is missing on server', 'crocoblock-wizard' );
	?></div>
	<p><?php
		_e( 'To continue the installation of the template, please ask your Hosting Provider to install the XMLReader PHP extension on your server.', 'crocoblock-wizard' );
	?></p>
</div>