<?php
/**
 * Frontend view
 *
 * @package offer-product-title
 */

?>
<div class="cartflows-pro-bb__offer-product-title">
	<?php
		echo do_shortcode( '[cartflows_offer_product_title]' );
	?>
</div>
