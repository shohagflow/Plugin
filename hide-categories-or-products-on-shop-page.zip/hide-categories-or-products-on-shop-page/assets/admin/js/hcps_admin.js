jQuery(document).ready(function () {
	jQuery(".hcps_select").chosen({
		no_results_text: "Oops, nothing found!"
	});
});