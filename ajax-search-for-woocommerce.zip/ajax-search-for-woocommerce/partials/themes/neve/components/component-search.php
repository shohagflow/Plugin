<?php
// Exit if accessed directly
if ( ! defined( 'DGWT_WCAS_FILE' ) ) {
	exit;
}
?>
<div class="component-wrap search-field">
	<div class="widget widget-search">
		<?php echo do_shortcode('[fibosearch]'); ?>
	</div>
</div>
