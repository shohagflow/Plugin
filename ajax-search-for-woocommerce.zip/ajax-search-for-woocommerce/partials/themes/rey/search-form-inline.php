<?php
// Exit if accessed directly
if ( ! defined( 'DGWT_WCAS_FILE' ) ) {
	exit;
}

echo '<div class="rey-headerIcon">';
echo do_shortcode( '[fibosearch layout="flex-icon-on-mobile"]' );
echo '</div>';
