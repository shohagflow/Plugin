<?php

namespace WPML\PB\Gutenberg;

interface Integration {

	public function add_hooks();
}
