<?php
namespace Webtomizer\WCDP;

if (!defined('ABSPATH')) {
    exit;
}

use stdClass;

/**
 * Automatic updater client
 */
class Envato_items_Update_Client
{

    /**
     * @var null
     */
    private static $_instance = null;

    /**
     * @var $item_id
     * @description Envato Item ID
     */
    private $item_id;
    /**
     * @var $purchase_code
     * @description Purchase code inserted by customer
     */
    private $purchase_code;
    /**
     * @var
     * @description Plugin file
     */
    private $plugin_file;
    /**
     * @var $update_endpoint
     * @description update endpoint
     */
    private $update_endpoint;
    /**
     * @var $verify_purchase_endpoint
     * @description verify purchase endpoint
     */
    private $verify_purchase_endpoint;

    /**
     * Constructor
     *
     * @param $item_id
     * @param $plugin_file
     * @param $update_endpoint
     * @param $verify_purchase_endppint
     * @param $purchase_code
     */
    private function __construct($args)
    {


        $args = wp_parse_args(
            $args,
            array(
                'item_id' => '',
                'plugin_file' => '',
                'update_endpoint' => '',
                'verify_purchase_endpoint' => '',
                'purchase_code' => ''
            )
        );

        extract($args);

        $this->item_id = $item_id;
        $this->plugin_file = $plugin_file;
        $this->update_endpoint = $update_endpoint;
        $this->verify_purchase_endpoint = $verify_purchase_endpoint;
        $this->purchase_code = $purchase_code;

        $this->init();
    }

    /**
     * @param $args
     *
     * @return self|null
     */
    static function instance($args)
    {
        if (!isset(self::$_instance)) {
            self::$_instance = new self($args);
        }

        return self::$_instance;
    }


    /**
     *  enable the client functionality
     * @return void
     */
    function init()
    {
        delete_site_transient('update_plugins');
        add_filter('pre_set_site_transient_update_plugins', array($this, 'check_for_update'));
        add_filter('plugins_api', array($this, 'plugin_information'), 20, 3);
        add_action('admin_print_footer_scripts-plugin-install.php', array($this, 'modify_iframe_content'));

    }

    function modify_iframe_content()
    {

        ?>
        <script>
            jQuery(document).ready(function ($) {
                if (document.URL.indexOf('tab=plugin-information&plugin=<?php echo $this->get_slug() ?>') == -1) return; //make sure we are targeting the correct plugin information page
                $('#section-description *').css('max-width', '100%');
            });
        </script>
        <?php
    }

    function get_slug()
    {
        return str_split($this->plugin_file, strpos($this->plugin_file, '/'))[0];
    }

    /**
     *  retrieve plugin information from update endpoint
     *
     * @param $data
     * @param $action
     * @param $args
     *
     * @return mixed|stdClass
     */
    function plugin_information($data, $action, $args)
    {

        if ($action !== 'plugin_information') {
            return $data;
        }


        if (!isset($args->slug) || ($args->slug !== $this->get_slug())) {
            return $data;
        }
        $cache_key = $this->get_slug() . '_api_request_' . substr(md5(serialize($this->get_slug())), 0, 15);

        $api_request_transient = get_site_transient($cache_key);
        $api_request_transient = ''; //todo change this back
        if (empty($api_request_transient)) { //no transient found, make api request
            $api_response = $this->get_remote_response();

            if (!$api_response) {
                return $data;
            }

            $data = new \stdClass();

            //extract plugin headers from response body
            $data->new_version = $api_response['metaData']['headers']['version'];
            $data->package = $api_response['package'];
            $data->slug = $this->get_slug();
            $data->sections = array();
            $data->banners = array();
            $data->download_link = $api_response['package'];

            foreach ($api_response['metaData']['headers'] as $headerKey => $header) {

                switch ($headerKey) {
                    case 'name':
                        $data->name = $api_response['metaData']['headers']['name'];
                        break;

                    case 'version':
                        $data->version = $api_response['metaData']['headers']['version'];
                        break;
                    case 'author':
                        if (isset($api_response['metaData']['headers']['authorURI'])) {
                            $data->author = '<a href="' . $api_response['metaData']['headers']['authorURI'] . '">' . $api_response['metaData']['headers']['author'] . '</a>';
                        } else {
                            $data->author = $api_response['metaData']['headers']['author'];
                        }

                        break;
                    case 'pluginURI':
                        $data->homepage = $api_response['metaData']['headers']['pluginURI'];
                        break;
                    case 'requires':
                        $data->requires = $api_response['metaData']['headers']['requires'];
                        break;

                    case 'tested':
                        $data->tested = $api_response['metaData']['headers']['tested'];
                        break;

                    case 'description':
                        $data->sections['description'] = "<div id='updateServerContent'> {$api_response['metaData']['headers']['description']} </div>";
                        break;

                }
            }

            if (isset($api_response['changelog'])) {
                $data->sections['changelog'] = nl2br($api_response['changelog']);
            }

            if (isset($api_response['metaData']['images'])) {

                //the WordPress core places the banner value in a css url( 'url' ) function without quotes, so it misinterprets the url
                //we need to replace the brackets with their url encoded values
                $banner = $api_response['metaData']['images']['banner'];
                $banner = str_replace('(', '%28', $banner);
                $banner = str_replace(')', '%29', $banner);
                $data->banners = [
                    'low' => $banner,
                    'high' => $banner
                ];
            }


            // Expires in 1 day
            set_site_transient($cache_key, $data, DAY_IN_SECONDS);
        }

        return $data;

    }

    /**
     *  verify purchase code request
     *
     * @param $purchase_code
     *
     * @return bool|string|\WP_Error
     */
    function verify_purchase_code($purchase_code)
    {


        $args = array('timeout' => 10);

        $request = wp_remote_post($this->verify_purchase_endpoint . $this->purchase_code, $args);

        if (is_array($request) && $request['response']['code'] == 200) {
            $response = json_decode(wp_remote_retrieve_body($request), true);

            if (is_array($response) && isset($response['success']) && $response['success'] == 1) {

                return 'valid';

            } else {
                return 'invalid';
            }

        } else {
            //an error occurred
            if (is_wp_error($request)) {
                return $request;
            }

            return false;
        }
    }

    /**
     *  get remote response for plugin information and update check
     * @return false|mixed|null
     */
    protected function get_remote_response()
    {

        $response = false;
        //include domain origin in headers
        $headers = array(
            'origin' => get_site_url(),
        );
        $args = array(
            'headers' => $headers,
            'timeout' => 10,
            'body' => array('itemId' => $this->item_id, 'purchaseCode' => $this->purchase_code)
        );
        $request = wp_remote_post($this->update_endpoint, $args);
        if (is_array($request) && $request['response']['code'] == 200) {
            $response = json_decode(wp_remote_retrieve_body($request), true);
        }
        return $response;
    }

    /**
     *  check for plugin updates
     *
     * @param $transient
     *
     * @return mixed
     */
    function check_for_update($transient)
    {
        //make api call
        $api_response = $this->get_remote_response();

        if (!$api_response)
            return $transient;
        //if new update is available add transient
        if (isset($api_response['metaData']['headers']) && is_array($api_response['metaData']['headers'])) {


            $plugin_data = get_plugin_data(WP_PLUGIN_DIR . '/' . $this->plugin_file);
            if (isset($api_response['metaData']['headers']['version']) && version_compare($api_response['metaData']['headers']['version'], $plugin_data['Version']) === 1) {

                $wp_response = new stdClass();
                $wp_response->slug = $this->get_slug();
                $wp_response->package = $api_response['package'];
                $wp_response->icons = array();
                foreach ($api_response['metaData']['headers'] as $headerKey => $header) {

                    switch ($headerKey) {
                        case 'name':
                            $wp_response->name = $api_response['metaData']['headers']['name'];
                            break;
                        case 'version':
                            $wp_response->new_version = $api_response['metaData']['headers']['version'];
                            break;
                        case 'author':
                            if (isset($api_response['metaData']['headers']['authorURI'])) {
                                $wp_response->author = '<a href="' . $api_response['metaData']['headers']['authorURI'] . '">' . $api_response['metaData']['headers']['author'] . '</a>';
                            } else {
                                $wp_response->author = $api_response['metaData']['headers']['author'];
                            }
                            break;

                        case 'tested':
                            $wp_response->tested = $api_response['metaData']['headers']['tested'];
                            break;

                        case 'package':
                            $wp_response->package = $api_response['metaData']['headers']['package'];
                            break;
                    }
                }
                if (isset($api_response['metaData']['images'])) {

                    //the WordPress core places the banner value in a css url( 'url' ) function without quotes, so it misinterprets the url
                    // we need to replace the brackets with their url encoded values
                    $icon = $api_response['metaData']['images']['icon'];
                    $icon = str_replace('(', '%28', $icon);
                    $icon = str_replace(')', '%29', $icon);
                    $wp_response->icons = ['default' => $icon];
                }

                $transient->response[$this->plugin_file] = $wp_response;
            }

        }

        return $transient;
    }

}