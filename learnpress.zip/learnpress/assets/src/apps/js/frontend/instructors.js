import InstructorList from './instructors/instructor-list';
InstructorList();

