export * from './question-types/index';
import QuestionTypes from './question-types/index';

export default QuestionTypes;
