<?php
/**
 * Fields edit course
 *
 * @since 4.2.7.6
 * @version 1.0.0
 */

if ( ! isset( $post_id ) ) {
	return;
}
