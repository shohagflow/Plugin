<?php
/**
 * Template for display a notice in admin
 *
 * @since 4.1.7.3.2
 * @version 1.0.0
 */

defined( 'ABSPATH' ) || exit;

wp_enqueue_script( 'lp-admin-notices' );
?>

<div class="lp-admin-notices notice">

</div>
