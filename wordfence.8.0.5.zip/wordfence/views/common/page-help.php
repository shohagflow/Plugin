<?php if (!defined('WORDFENCE_VERSION')) { exit; } ?>
<div class="wf-help-link"><a href="<?php echo $link; ?>" target="_blank" rel="noopener noreferrer" class="wfhelp"></a><a href="<?php echo $link; ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html($title); ?><span class="screen-reader-text"> (<?php esc_html_e('opens in new tab', 'wordfence') ?>)</span></a></div>
