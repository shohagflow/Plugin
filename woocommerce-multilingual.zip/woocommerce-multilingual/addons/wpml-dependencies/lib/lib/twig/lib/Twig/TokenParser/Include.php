<?php

namespace WPML\Core;

use WPML\Core\Twig\TokenParser\IncludeTokenParser;
\class_exists('WPML\\Core\\Twig\\TokenParser\\IncludeTokenParser');
if (\false) {
    class Twig_TokenParser_Include extends \WPML\Core\Twig\TokenParser\IncludeTokenParser
    {
    }
}
