<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\Expression\Test\EvenTest;
\class_exists('WPML\\Core\\Twig\\Node\\Expression\\Test\\EvenTest');
if (\false) {
    class Twig_Node_Expression_Test_Even extends \WPML\Core\Twig\Node\Expression\Test\EvenTest
    {
    }
}
