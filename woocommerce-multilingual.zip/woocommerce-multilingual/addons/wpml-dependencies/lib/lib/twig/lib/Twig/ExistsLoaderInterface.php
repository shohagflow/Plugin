<?php

namespace WPML\Core;

use WPML\Core\Twig\Loader\ExistsLoaderInterface;
\class_exists('WPML\\Core\\Twig\\Loader\\ExistsLoaderInterface');
if (\false) {
    class Twig_ExistsLoaderInterface extends \WPML\Core\Twig\Loader\ExistsLoaderInterface
    {
    }
}
