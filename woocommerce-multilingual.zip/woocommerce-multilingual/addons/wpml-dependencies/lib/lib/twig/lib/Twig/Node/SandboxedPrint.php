<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\SandboxedPrintNode;
\class_exists('WPML\\Core\\Twig\\Node\\SandboxedPrintNode');
if (\false) {
    class Twig_Node_SandboxedPrint extends \WPML\Core\Twig\Node\SandboxedPrintNode
    {
    }
}
