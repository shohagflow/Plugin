<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\NodeOutputInterface;
\class_exists('WPML\\Core\\Twig\\Node\\NodeOutputInterface');
if (\false) {
    class Twig_NodeOutputInterface extends \WPML\Core\Twig\Node\NodeOutputInterface
    {
    }
}
