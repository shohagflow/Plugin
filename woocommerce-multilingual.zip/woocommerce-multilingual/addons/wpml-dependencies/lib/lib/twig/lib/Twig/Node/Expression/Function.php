<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\Expression\FunctionExpression;
\class_exists('WPML\\Core\\Twig\\Node\\Expression\\FunctionExpression');
if (\false) {
    class Twig_Node_Expression_Function extends \WPML\Core\Twig\Node\Expression\FunctionExpression
    {
    }
}
