<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\IfNode;
\class_exists('WPML\\Core\\Twig\\Node\\IfNode');
if (\false) {
    class Twig_Node_If extends \WPML\Core\Twig\Node\IfNode
    {
    }
}
