<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\Expression\Filter\DefaultFilter;
\class_exists('WPML\\Core\\Twig\\Node\\Expression\\Filter\\DefaultFilter');
if (\false) {
    class Twig_Node_Expression_Filter_Default extends \WPML\Core\Twig\Node\Expression\Filter\DefaultFilter
    {
    }
}
