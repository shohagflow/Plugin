<?php

namespace WPML\Core;

use WPML\Core\Twig\TokenParser\FilterTokenParser;
\class_exists('WPML\\Core\\Twig\\TokenParser\\FilterTokenParser');
if (\false) {
    class Twig_TokenParser_Filter extends \WPML\Core\Twig\TokenParser\FilterTokenParser
    {
    }
}
