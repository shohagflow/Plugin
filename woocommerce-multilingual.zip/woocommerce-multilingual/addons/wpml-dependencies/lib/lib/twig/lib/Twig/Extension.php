<?php

namespace WPML\Core;

use WPML\Core\Twig\Extension\AbstractExtension;
\class_exists('WPML\\Core\\Twig\\Extension\\AbstractExtension');
if (\false) {
    class Twig_Extension extends \WPML\Core\Twig\Extension\AbstractExtension
    {
    }
}
