<?php

namespace WPML\Core;

use WPML\Core\Twig\Extension\CoreExtension;
\class_exists('WPML\\Core\\Twig\\Extension\\CoreExtension');
if (\false) {
    class Twig_Extension_Core extends \WPML\Core\Twig\Extension\CoreExtension
    {
    }
}
