<?php

namespace WPML\Core;

use WPML\Core\Twig\Sandbox\SecurityNotAllowedTagError;
\class_exists('WPML\\Core\\Twig\\Sandbox\\SecurityNotAllowedTagError');
if (\false) {
    class Twig_Sandbox_SecurityNotAllowedTagError extends \WPML\Core\Twig\Sandbox\SecurityNotAllowedTagError
    {
    }
}
