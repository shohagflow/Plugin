<?php

namespace WPML\Core;

use WPML\Core\Twig\Compiler;
\class_exists('WPML\\Core\\Twig\\Compiler');
if (\false) {
    class Twig_Compiler extends \WPML\Core\Twig\Compiler
    {
    }
}
