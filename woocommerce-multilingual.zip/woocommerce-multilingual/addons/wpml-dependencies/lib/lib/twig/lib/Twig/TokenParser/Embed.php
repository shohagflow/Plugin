<?php

namespace WPML\Core;

use WPML\Core\Twig\TokenParser\EmbedTokenParser;
\class_exists('WPML\\Core\\Twig\\TokenParser\\EmbedTokenParser');
if (\false) {
    class Twig_TokenParser_Embed extends \WPML\Core\Twig\TokenParser\EmbedTokenParser
    {
    }
}
