<?php

namespace WPML\Core;

use WPML\Core\Twig\TemplateWrapper;
\class_exists('WPML\\Core\\Twig\\TemplateWrapper');
if (\false) {
    class Twig_TemplateWrapper extends \WPML\Core\Twig\TemplateWrapper
    {
    }
}
