<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\Expression\Binary\MatchesBinary;
\class_exists('WPML\\Core\\Twig\\Node\\Expression\\Binary\\MatchesBinary');
if (\false) {
    class Twig_Node_Expression_Binary_Matches extends \WPML\Core\Twig\Node\Expression\Binary\MatchesBinary
    {
    }
}
