<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\Expression\NullCoalesceExpression;
\class_exists('WPML\\Core\\Twig\\Node\\Expression\\NullCoalesceExpression');
if (\false) {
    class Twig_Node_Expression_NullCoalesce extends \WPML\Core\Twig\Node\Expression\NullCoalesceExpression
    {
    }
}
