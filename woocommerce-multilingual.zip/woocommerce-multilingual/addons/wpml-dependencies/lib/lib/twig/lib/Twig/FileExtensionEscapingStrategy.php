<?php

namespace WPML\Core;

use WPML\Core\Twig\FileExtensionEscapingStrategy;
\class_exists('WPML\\Core\\Twig\\FileExtensionEscapingStrategy');
if (\false) {
    class Twig_FileExtensionEscapingStrategy extends \WPML\Core\Twig\FileExtensionEscapingStrategy
    {
    }
}
