<?php

namespace WPML\Core;

use WPML\Core\Twig\TokenParser\FromTokenParser;
\class_exists('WPML\\Core\\Twig\\TokenParser\\FromTokenParser');
if (\false) {
    class Twig_TokenParser_From extends \WPML\Core\Twig\TokenParser\FromTokenParser
    {
    }
}
