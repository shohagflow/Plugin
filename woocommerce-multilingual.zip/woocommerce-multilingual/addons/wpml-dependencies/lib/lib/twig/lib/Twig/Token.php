<?php

namespace WPML\Core;

use WPML\Core\Twig\Token;
\class_exists('WPML\\Core\\Twig\\Token');
if (\false) {
    class Twig_Token extends \WPML\Core\Twig\Token
    {
    }
}
