<?php

namespace WPML\Core;

use WPML\Core\Twig\Error\RuntimeError;
\class_exists('WPML\\Core\\Twig\\Error\\RuntimeError');
if (\false) {
    class Twig_Error_Runtime extends \WPML\Core\Twig\Error\RuntimeError
    {
    }
}
