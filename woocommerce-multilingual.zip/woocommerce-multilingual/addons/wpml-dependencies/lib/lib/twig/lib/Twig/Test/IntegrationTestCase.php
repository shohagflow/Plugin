<?php

namespace WPML\Core;

use WPML\Core\Twig\Test\IntegrationTestCase;
\class_exists('WPML\\Core\\Twig\\Test\\IntegrationTestCase');
if (\false) {
    class Twig_Test_IntegrationTestCase extends \WPML\Core\Twig\Test\IntegrationTestCase
    {
    }
}
