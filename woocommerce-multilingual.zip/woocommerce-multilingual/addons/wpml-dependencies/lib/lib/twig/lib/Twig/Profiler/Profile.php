<?php

namespace WPML\Core;

use WPML\Core\Twig\Profiler\Profile;
\class_exists('WPML\\Core\\Twig\\Profiler\\Profile');
if (\false) {
    class Twig_Profiler_Profile extends \WPML\Core\Twig\Profiler\Profile
    {
    }
}
