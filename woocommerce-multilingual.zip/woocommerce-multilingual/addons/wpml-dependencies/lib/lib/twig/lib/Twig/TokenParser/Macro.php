<?php

namespace WPML\Core;

use WPML\Core\Twig\TokenParser\MacroTokenParser;
\class_exists('WPML\\Core\\Twig\\TokenParser\\MacroTokenParser');
if (\false) {
    class Twig_TokenParser_Macro extends \WPML\Core\Twig\TokenParser\MacroTokenParser
    {
    }
}
