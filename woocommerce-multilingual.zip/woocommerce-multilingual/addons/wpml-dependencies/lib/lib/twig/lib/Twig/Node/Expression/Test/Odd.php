<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\Expression\Test\OddTest;
\class_exists('WPML\\Core\\Twig\\Node\\Expression\\Test\\OddTest');
if (\false) {
    class Twig_Node_Expression_Test_Odd extends \WPML\Core\Twig\Node\Expression\Test\OddTest
    {
    }
}
