<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\ForNode;
\class_exists('WPML\\Core\\Twig\\Node\\ForNode');
if (\false) {
    class Twig_Node_For extends \WPML\Core\Twig\Node\ForNode
    {
    }
}
