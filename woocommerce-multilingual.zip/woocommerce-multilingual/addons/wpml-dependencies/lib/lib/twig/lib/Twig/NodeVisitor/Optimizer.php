<?php

namespace WPML\Core;

use WPML\Core\Twig\NodeVisitor\OptimizerNodeVisitor;
\class_exists('WPML\\Core\\Twig\\NodeVisitor\\OptimizerNodeVisitor');
if (\false) {
    class Twig_NodeVisitor_Optimizer extends \WPML\Core\Twig\NodeVisitor\OptimizerNodeVisitor
    {
    }
}
