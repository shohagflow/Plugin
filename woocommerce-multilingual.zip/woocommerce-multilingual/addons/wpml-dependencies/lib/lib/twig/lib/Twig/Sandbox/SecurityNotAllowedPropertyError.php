<?php

namespace WPML\Core;

use WPML\Core\Twig\Sandbox\SecurityNotAllowedPropertyError;
\class_exists('WPML\\Core\\Twig\\Sandbox\\SecurityNotAllowedPropertyError');
if (\false) {
    class Twig_Sandbox_SecurityNotAllowedPropertyError extends \WPML\Core\Twig\Sandbox\SecurityNotAllowedPropertyError
    {
    }
}
