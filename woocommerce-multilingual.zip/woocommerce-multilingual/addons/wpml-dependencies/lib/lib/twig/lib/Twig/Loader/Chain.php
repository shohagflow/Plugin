<?php

namespace WPML\Core;

use WPML\Core\Twig\Loader\ChainLoader;
\class_exists('WPML\\Core\\Twig\\Loader\\ChainLoader');
if (\false) {
    class Twig_Loader_Chain extends \WPML\Core\Twig\Loader\ChainLoader
    {
    }
}
