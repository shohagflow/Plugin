<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\DeprecatedNode;
\class_exists('WPML\\Core\\Twig\\Node\\DeprecatedNode');
if (\false) {
    class Twig_Node_Deprecated extends \WPML\Core\Twig\Node\DeprecatedNode
    {
    }
}
