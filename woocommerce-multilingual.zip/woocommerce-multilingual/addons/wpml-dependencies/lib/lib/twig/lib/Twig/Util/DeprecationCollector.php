<?php

namespace WPML\Core;

use WPML\Core\Twig\Util\DeprecationCollector;
\class_exists('WPML\\Core\\Twig\\Util\\DeprecationCollector');
if (\false) {
    class Twig_Util_DeprecationCollector extends \WPML\Core\Twig\Util\DeprecationCollector
    {
    }
}
