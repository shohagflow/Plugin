<?php

namespace WPML\Core;

use WPML\Core\Twig\Cache\CacheInterface;
\class_exists('WPML\\Core\\Twig\\Cache\\CacheInterface');
if (\false) {
    class Twig_CacheInterface extends \WPML\Core\Twig\Cache\CacheInterface
    {
    }
}
