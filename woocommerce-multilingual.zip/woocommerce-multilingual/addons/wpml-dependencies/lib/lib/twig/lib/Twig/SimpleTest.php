<?php

namespace WPML\Core;

use WPML\Core\Twig\TwigTest;
\class_exists('WPML\\Core\\Twig\\TwigTest');
if (\false) {
    class Twig_SimpleTest extends \WPML\Core\Twig\TwigTest
    {
    }
}
