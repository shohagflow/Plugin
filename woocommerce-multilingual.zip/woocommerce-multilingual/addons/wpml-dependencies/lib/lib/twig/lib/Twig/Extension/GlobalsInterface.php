<?php

namespace WPML\Core;

use WPML\Core\Twig\Extension\GlobalsInterface;
\class_exists('WPML\\Core\\Twig\\Extension\\GlobalsInterface');
if (\false) {
    class Twig_Extension_GlobalsInterface extends \WPML\Core\Twig\Extension\GlobalsInterface
    {
    }
}
