<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\Expression\TestExpression;
\class_exists('WPML\\Core\\Twig\\Node\\Expression\\TestExpression');
if (\false) {
    class Twig_Node_Expression_Test extends \WPML\Core\Twig\Node\Expression\TestExpression
    {
    }
}
