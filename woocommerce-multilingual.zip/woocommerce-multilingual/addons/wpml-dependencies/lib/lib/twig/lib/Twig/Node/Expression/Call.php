<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\Expression\CallExpression;
\class_exists('WPML\\Core\\Twig\\Node\\Expression\\CallExpression');
if (\false) {
    class Twig_Node_Expression_Call extends \WPML\Core\Twig\Node\Expression\CallExpression
    {
    }
}
