<?php

namespace WPML\Core;

use WPML\Core\Twig\RuntimeLoader\ContainerRuntimeLoader;
\class_exists('WPML\\Core\\Twig\\RuntimeLoader\\ContainerRuntimeLoader');
if (\false) {
    class Twig_ContainerRuntimeLoader extends \WPML\Core\Twig\RuntimeLoader\ContainerRuntimeLoader
    {
    }
}
