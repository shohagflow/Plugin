<?php

namespace WPML\Core;

use WPML\Core\Twig\Loader\SourceContextLoaderInterface;
\class_exists('WPML\\Core\\Twig\\Loader\\SourceContextLoaderInterface');
if (\false) {
    class Twig_SourceContextLoaderInterface extends \WPML\Core\Twig\Loader\SourceContextLoaderInterface
    {
    }
}
