<?php

namespace WPML\Core;

use WPML\Core\Twig\TokenParser\SandboxTokenParser;
\class_exists('WPML\\Core\\Twig\\TokenParser\\SandboxTokenParser');
if (\false) {
    class Twig_TokenParser_Sandbox extends \WPML\Core\Twig\TokenParser\SandboxTokenParser
    {
    }
}
