<?php

namespace WPML\Core;

use WPML\Core\Twig\Source;
\class_exists('WPML\\Core\\Twig\\Source');
if (\false) {
    class Twig_Source extends \WPML\Core\Twig\Source
    {
    }
}
