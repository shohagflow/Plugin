<?php

namespace WPML\Core;

use WPML\Core\Twig\TokenParser\AutoEscapeTokenParser;
\class_exists('WPML\\Core\\Twig\\TokenParser\\AutoEscapeTokenParser');
if (\false) {
    class Twig_TokenParser_AutoEscape extends \WPML\Core\Twig\TokenParser\AutoEscapeTokenParser
    {
    }
}
