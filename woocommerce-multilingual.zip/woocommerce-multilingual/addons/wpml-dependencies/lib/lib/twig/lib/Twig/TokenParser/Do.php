<?php

namespace WPML\Core;

use WPML\Core\Twig\TokenParser\DoTokenParser;
\class_exists('WPML\\Core\\Twig\\TokenParser\\DoTokenParser');
if (\false) {
    class Twig_TokenParser_Do extends \WPML\Core\Twig\TokenParser\DoTokenParser
    {
    }
}
