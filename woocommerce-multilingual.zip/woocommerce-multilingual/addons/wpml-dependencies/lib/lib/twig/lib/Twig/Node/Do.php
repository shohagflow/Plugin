<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\DoNode;
\class_exists('WPML\\Core\\Twig\\Node\\DoNode');
if (\false) {
    class Twig_Node_Do extends \WPML\Core\Twig\Node\DoNode
    {
    }
}
