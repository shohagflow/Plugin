<?php

namespace WPML\Core;

use WPML\Core\Twig\Profiler\Node\LeaveProfileNode;
\class_exists('WPML\\Core\\Twig\\Profiler\\Node\\LeaveProfileNode');
if (\false) {
    class Twig_Profiler_Node_LeaveProfile extends \WPML\Core\Twig\Profiler\Node\LeaveProfileNode
    {
    }
}
