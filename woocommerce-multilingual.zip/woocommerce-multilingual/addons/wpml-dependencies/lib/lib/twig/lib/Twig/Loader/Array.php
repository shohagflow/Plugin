<?php

namespace WPML\Core;

use WPML\Core\Twig\Loader\ArrayLoader;
\class_exists('WPML\\Core\\Twig\\Loader\\ArrayLoader');
if (\false) {
    class Twig_Loader_Array extends \WPML\Core\Twig\Loader\ArrayLoader
    {
    }
}
