<?php

namespace WPML\Core;

use WPML\Core\Twig\Profiler\NodeVisitor\ProfilerNodeVisitor;
\class_exists('WPML\\Core\\Twig\\Profiler\\NodeVisitor\\ProfilerNodeVisitor');
if (\false) {
    class Twig_Profiler_NodeVisitor_Profiler extends \WPML\Core\Twig\Profiler\NodeVisitor\ProfilerNodeVisitor
    {
    }
}
