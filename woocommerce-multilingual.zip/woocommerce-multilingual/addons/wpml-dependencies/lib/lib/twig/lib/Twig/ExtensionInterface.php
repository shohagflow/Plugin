<?php

namespace WPML\Core;

use WPML\Core\Twig\Extension\ExtensionInterface;
\class_exists('WPML\\Core\\Twig\\Extension\\ExtensionInterface');
if (\false) {
    class Twig_ExtensionInterface extends \WPML\Core\Twig\Extension\ExtensionInterface
    {
    }
}
