<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\BlockNode;
\class_exists('WPML\\Core\\Twig\\Node\\BlockNode');
if (\false) {
    class Twig_Node_Block extends \WPML\Core\Twig\Node\BlockNode
    {
    }
}
