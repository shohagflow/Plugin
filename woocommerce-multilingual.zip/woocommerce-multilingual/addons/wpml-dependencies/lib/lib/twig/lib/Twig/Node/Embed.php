<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\EmbedNode;
\class_exists('WPML\\Core\\Twig\\Node\\EmbedNode');
if (\false) {
    class Twig_Node_Embed extends \WPML\Core\Twig\Node\EmbedNode
    {
    }
}
