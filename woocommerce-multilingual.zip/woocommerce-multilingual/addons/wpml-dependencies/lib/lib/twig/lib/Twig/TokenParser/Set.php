<?php

namespace WPML\Core;

use WPML\Core\Twig\TokenParser\SetTokenParser;
\class_exists('WPML\\Core\\Twig\\TokenParser\\SetTokenParser');
if (\false) {
    class Twig_TokenParser_Set extends \WPML\Core\Twig\TokenParser\SetTokenParser
    {
    }
}
