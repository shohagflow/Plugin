<?php

namespace WPML\Core;

use WPML\Core\Twig\Parser;
\class_exists('WPML\\Core\\Twig\\Parser');
if (\false) {
    class Twig_Parser extends \WPML\Core\Twig\Parser
    {
    }
}
