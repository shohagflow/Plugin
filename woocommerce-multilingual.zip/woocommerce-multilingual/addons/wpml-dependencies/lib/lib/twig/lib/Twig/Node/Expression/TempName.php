<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\Expression\TempNameExpression;
\class_exists('WPML\\Core\\Twig\\Node\\Expression\\TempNameExpression');
if (\false) {
    class Twig_Node_Expression_TempName extends \WPML\Core\Twig\Node\Expression\TempNameExpression
    {
    }
}
