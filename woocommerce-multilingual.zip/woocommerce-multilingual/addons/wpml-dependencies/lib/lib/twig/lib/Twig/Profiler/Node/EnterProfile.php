<?php

namespace WPML\Core;

use WPML\Core\Twig\Profiler\Node\EnterProfileNode;
\class_exists('WPML\\Core\\Twig\\Profiler\\Node\\EnterProfileNode');
if (\false) {
    class Twig_Profiler_Node_EnterProfile extends \WPML\Core\Twig\Profiler\Node\EnterProfileNode
    {
    }
}
