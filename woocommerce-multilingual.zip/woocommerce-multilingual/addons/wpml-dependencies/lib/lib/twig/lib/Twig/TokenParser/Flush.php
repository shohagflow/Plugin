<?php

namespace WPML\Core;

use WPML\Core\Twig\TokenParser\FlushTokenParser;
\class_exists('WPML\\Core\\Twig\\TokenParser\\FlushTokenParser');
if (\false) {
    class Twig_TokenParser_Flush extends \WPML\Core\Twig\TokenParser\FlushTokenParser
    {
    }
}
