<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\Expression\Test\DivisiblebyTest;
\class_exists('WPML\\Core\\Twig\\Node\\Expression\\Test\\DivisiblebyTest');
if (\false) {
    class Twig_Node_Expression_Test_Divisibleby extends \WPML\Core\Twig\Node\Expression\Test\DivisiblebyTest
    {
    }
}
