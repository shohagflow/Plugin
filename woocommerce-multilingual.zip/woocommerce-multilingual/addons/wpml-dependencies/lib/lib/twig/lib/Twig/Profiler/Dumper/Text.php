<?php

namespace WPML\Core;

use WPML\Core\Twig\Profiler\Dumper\TextDumper;
\class_exists('WPML\\Core\\Twig\\Profiler\\Dumper\\TextDumper');
if (\false) {
    class Twig_Profiler_Dumper_Text extends \WPML\Core\Twig\Profiler\Dumper\TextDumper
    {
    }
}
