<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\WithNode;
\class_exists('WPML\\Core\\Twig\\Node\\WithNode');
if (\false) {
    class Twig_Node_With extends \WPML\Core\Twig\Node\WithNode
    {
    }
}
