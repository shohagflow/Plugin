<?php

namespace WPML\Core;

use WPML\Core\Twig\Node\ModuleNode;
\class_exists('WPML\\Core\\Twig\\Node\\ModuleNode');
if (\false) {
    class Twig_Node_Module extends \WPML\Core\Twig\Node\ModuleNode
    {
    }
}
