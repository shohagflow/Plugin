<?php

namespace WPML\Core;

use WPML\Core\Twig\TokenStream;
\class_exists('WPML\\Core\\Twig\\TokenStream');
if (\false) {
    class Twig_TokenStream extends \WPML\Core\Twig\TokenStream
    {
    }
}
