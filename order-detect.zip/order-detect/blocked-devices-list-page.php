<?php
// Create the blocked devices list page
function blocked_devices_list_page() {
    $blocked_devices_file = plugin_dir_path(__FILE__) . 'blocked-devices.json';

    if (!file_exists($blocked_devices_file)) {
        echo '<div class="wrap"><h1>Blocked Devices List</h1><p>No blocked devices found.</p></div>';
        return;
    }

    $blocked_devices = json_decode(file_get_contents($blocked_devices_file), true);

    if (isset($_POST['block_device'])) {
        $device_id_to_block = $_POST['device_id'];
        $blocked_devices[$device_id_to_block]['blocked_until'] = current_time('timestamp') + (5259492 * 60);
        file_put_contents($blocked_devices_file, json_encode($blocked_devices));
    }

    if (isset($_POST['unblock_device'])) {
        $device_id_to_unblock = $_POST['device_id'];
        unset($blocked_devices[$device_id_to_unblock]['blocked_until']);
        file_put_contents($blocked_devices_file, json_encode($blocked_devices));
    }

    // Filter by phone number
    $filtered_phone_number = isset($_POST['filter_phone_number']) ? sanitize_text_field($_POST['filter_phone_number']) : '';

    ?>

	<style>
		.notice-warning {
   		 display: none;
		}

	</style>

    <div class="wrap">
        <h1 style="margin-bottom: 10px;font-weight:600;color:#2271B1;">Blocked Devices List</h1>
        <form method="post" action="" style="margin-bottom: 10px;">
            <input style="width: 200px;border:1px solid #2271B1" type="text" name="filter_phone_number" value="<?php echo esc_attr($filtered_phone_number); ?>" placeholder="Enter phone number">
            <input type="submit" value="Filter" class="button button-primary">
        </form>
        <table class="widefat fixed" cellspacing="0" style="text-align: center;">
            <thead>
                <tr style="background-color: #2271B1;">
                    <th style="color:#fff; border-right: 1px solid #fff; text-align:center;">List Identifier</th>
                    <th style="color:#fff; border-right: 1px solid #fff; text-align:center;">Device ID</th>
                    <th style="color:#fff; border-right: 1px solid #fff; text-align:center;">Phone Number</th>
                    <th style="color:#fff; border-right: 1px solid #fff; text-align:center;">IP Address</th>
                    <th style="color:#fff; border-right: 1px solid #fff; text-align:center;">Total Order Count</th>
                    <th style="color:#fff; border-right: 1px solid #fff; text-align:center;">Blocked Until</th>
                    <th style="color:#fff; border-right: 1px solid #fff; text-align:center;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($blocked_devices as $device_id => $info) : 
                    if ($filtered_phone_number && strpos($info['phone_number'], $filtered_phone_number) === false) {
                        continue; // Skip if phone number doesn't match the filter
                    }
                ?>
                    <tr>
                        <td style="border-right:1px solid #C7E3F9; border-bottom: 1px solid #C7E3F9"><?php echo esc_html($device_id); ?></td>
                        <td style="border-right:1px solid #C7E3F9; border-bottom: 1px solid #C7E3F9"><?php echo esc_html($info['device_id']); ?></td>
                        <td style="border-right:1px solid #C7E3F9; border-bottom: 1px solid #C7E3F9"><?php echo esc_html($info['phone_number']); ?></td>
                        <td style="border-right:1px solid #C7E3F9; border-bottom: 1px solid #C7E3F9"><?php echo esc_html($info['ip_address']); ?></td>
                        <td style="border-right:1px solid #C7E3F9; border-bottom: 1px solid #C7E3F9"><?php echo isset($info['count']) ? esc_html($info['count']) : '0'; ?></td>
                        <td style="border-right:1px solid #C7E3F9; border-bottom: 1px solid #C7E3F9">
                            <?php if (isset($info['blocked_until']) && time() < $info['blocked_until']) : ?>
                                <?php echo date('Y-m-d H:i:s', $info['blocked_until']); ?>
                            <?php else : ?>
                                Not Blocked
                            <?php endif; ?>
                        </td>
                        <td style="border-right:1px solid #C7E3F9; border-bottom: 1px solid #C7E3F9">
                            <form method="post" action="">
                                <input type="hidden" name="device_id" value="<?php echo esc_attr($device_id); ?>">
                                <?php if (isset($info['blocked_until']) && time() < $info['blocked_until']) : ?>
                                    <input type="submit" name="unblock_device" value="Unblock" class="button button-primary">
                                <?php else : ?>
                                    <input type="submit" name="block_device" value="Block" class="button button-secondary">
                                <?php endif; ?>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php
}
?>
