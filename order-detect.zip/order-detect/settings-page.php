<?php
// Create the settings menu
function order_limit_blocker_menu() {
//     add_menu_page('Set Block Timer', 'Set Block Timer', 'manage_options', 'order-limit-blocker', 'order_limit_blocker_settings_page');
//     add_submenu_page('order-limit-blocker', 'Block List', 'Block List', 'manage_options', 'blocked-devices-list', 'blocked_devices_list_page');
}

// Register settings
function order_limit_blocker_settings() {
    register_setting('order-limit-blocker-settings-group', 'max_orders');
    register_setting('order-limit-blocker-settings-group', 'block_duration');
}

// Create the settings page
function order_limit_blocker_settings_page() {
    ?>
	<style>
		.notice-warning {
   		 display: none;
		}
		
		
		#submit {
   	 	background: #45AAD5;
    	border: none;
    	font-size: 18px;
		}
		input[type=number] {
    	border: 2px solid #45AAD5;
		}

	</style>
    <div class="wrap" style="width: 100%;height:90vh;display:flex;justify-content:center;align-items:center">
        <div style="background-color: #fff;padding:20px;border-radius:10px;box-shadow: rgba(100, 100, 111, 0.2) 0px 7px 29px 0px;">
            <h1 style="font-weight:600;text-align:center;color:#45AAD5;">Set Order & Time Limit</h1>
            <form method="post" action="options.php">
                <?php settings_fields('order-limit-blocker-settings-group'); ?>
                <?php do_settings_sections('order-limit-blocker-settings-group'); ?>
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row">Maximum Orders</th>
                        <td><input type="number" name="max_orders" value="<?php echo esc_attr(get_option('max_orders', 5)); ?>" /></td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Block Duration (minutes)</th>
                        <td><input type="number" name="block_duration" value="<?php echo esc_attr(get_option('block_duration', 60)); ?>" /></td>
                    </tr>
                </table>
                <div style="display: flex;justify-content:center;">
                    <?php submit_button(); ?>
                </div>
            </form>
        </div>
    </div>
    <?php
}
?>
