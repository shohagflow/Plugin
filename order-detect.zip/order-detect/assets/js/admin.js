(function ($) {
	"use strict";

	$.orderDetect = $.orderDetect || {};
	$(document).ready(function () {
		let activeTab = 'license';
		const qVars = $.orderDetect.get_query_vars();
		if (qVars.page === "order-detect" && qVars.tab && qVars.tab !== "undefined") {
			activeTab = qVars.tab;
		}
		$.orderDetect.setActiveTab(activeTab);
		$.orderDetect.init();
	});

	$.orderDetect.get_query_vars = function () {
		const vars = {};
		window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function (m, key, value) {
			vars[key] = value;
		});
		return vars;
	};

	$.orderDetect.init = function () {
		$.orderDetect.bindEvents();
	};

	$.orderDetect.bindEvents = function () {
		$('.order-detect-settings-button').removeClass('button');
		$(document).on('click', '#enable_otp', function () {
			$.orderDetect.toggleOtpSettings();
		});
		$.orderDetect.toggleOtpSettings();

		$(document).on('click', '#enable_footer_text', function () {
			$.orderDetect.toggleOtpSettings();
		});
	};

	$.orderDetect.settingsTab = function (button) {
		const tabToGo = $(button).data("tab");
		$.orderDetect.setActiveTab(tabToGo);
	};

	$(".order-detect-settings-menu li").on("click", function () {
		$.orderDetect.settingsTab(this);
	});

	$.orderDetect.setActiveTab = function (tab) {
		if(!tab){
			tab = 'license';
		}
		$('.order-detect-settings-menu li[data-tab="' + tab + '"]').addClass("active").siblings().removeClass("active");
		$("#order-detect-" + tab).addClass("active").siblings().removeClass("active");
		const qVars = $.orderDetect.get_query_vars();
		if (qVars.page === "order-detect") {
			const baseUrl = window.location.href.split('?')[0] + '?page=order-detect';
			const newUrl = baseUrl + '&tab=' + tab;
			history.replaceState(null, '', newUrl);
		}
	};

	$.orderDetect.toggleOtpSettings = function () {
		const isChecked = $('#enable_otp').is(':checked');
		$('#order-detect-meta-checkout_otp_message').toggle(isChecked);

		const isCheckedFooterText= $('#enable_footer_text').is(':checked');
		$('#order-detect-meta-footer_text_heading').toggle(isCheckedFooterText);
		$('#order-detect-meta-footer_text_details').toggle(isCheckedFooterText);
	};
	
	$(document).on('click', '#license-submit', function(){
		let license_key = $("#orderdetect_license_key").val();
		let $message = $('.order-detect-license-status');
		let that = $(this); 
		if(license_key !=''){
			that.html(order_detect.loader);
			that.prop("disabled",true);
			$.ajax({
				type: 'POST',
				dataType: 'json',
				url: order_detect.ajax_url,
				data: {
					action: 'license_activate',
					security: order_detect.nonce,
					license_key: license_key
				},
				success: function(response, textStatus, jqXHR) {
					var statusCode = jqXHR.status;
					$message.removeClass('order-detect-license-status-success order-detect-license-status-error');
					if (statusCode === 200) {
						$message.addClass(response.class).text(response.message).show();
						that.html('');
						that.html(order_detect.activate);
						that.prop("disabled",false);
						setTimeout(function() {
							location.reload();
						}, 2000);
					} else {
						$message.addClass(response.class).text(response.message).show();
					}
				},
				error: function(jqXHR) {
					var response = jqXHR.responseJSON;
					$message.addClass(response.class).text(response.message).show();
					that.html('');
					that.html(order_detect.activate);
					that.prop("disabled",false);
				}
			});
		}
	});

	$(document).on('click', '#license-deactivate', function(){
		var confirmDeactivation = confirm('Are you sure you want to deactivate the license key?');
        if (!confirmDeactivation) {
            return;
        }
		let $message = $('.order-detect-license-status');
		let that = $(this); 
		that.html(order_detect.loader);
		that.prop("disabled",true);
		$.ajax({
			type: 'POST',
			dataType: 'json',
			url: order_detect.ajax_url,
			data: {
				action: 'license_deactivate',
				security: order_detect.nonce,
			},
			success: function(response, textStatus, jqXHR) {
				var statusCode = jqXHR.status;
				$message.removeClass('order-detect-license-status-success order-detect-license-status-error');
				if (statusCode === 200) {
					$message.addClass(response.class).text(response.message).show();
					that.html('');
					that.html(order_detect.activate);
					that.prop("disabled",false);
					setTimeout(function() {
					location.reload();
					}, 2000);
				} else {
					$message.addClass(response.class).text(response.message).show();
				}
			},
			error: function(jqXHR) {
				var response = jqXHR.responseJSON;
				$message.addClass(response.class).text(response.message).show();
				that.html('');
				that.html(order_detect.activate);
				that.prop("disabled",false);
			}
		});
	});

	$(document).on('click', '.multi-order-preview', function(e) {
        e.preventDefault();
        e.stopPropagation();
        var modalDialog = $(this).closest('td').find('.order-detect-modal-dialog');
        modalDialog.find('.order-detect-modal-content, .order-detect-modal-backdrop').show();
		let maxHeight = ($( window ).height() * 0.75) - 200;
		modalDialog.find('.wc-order-preview-table-wrapper').css({
			'max-height': maxHeight + 'px'
		});
		$('body').addClass('stop-scroll');
    });

    $(document).on('click', '.order-detect-modal-close, .order-detect-modal-backdrop', function(e) {
        e.preventDefault();
        e.stopPropagation();
        var modalDialog = $(this).closest('.order-detect-modal-dialog');
        modalDialog.find('.order-detect-modal-content, .order-detect-modal-backdrop').hide();
		$('body').removeClass('stop-scroll');
    });

    $(document).on('click', '.order-detect-modal-content', function(e) {
        e.stopPropagation();
    });

	var orderIds = jQuery('.multi-order-preview').map(function() {
		return jQuery(this).data('order-id');
	}).get();

	let currentIndex = 0;
	function loadOrder(orderID) {
        $.ajax({
            url: order_detect.ajax_url,
            type: 'POST',
			dataType: 'json',
            data: {
                action: 'load_order_by_phone',
                order_id: orderID,
                security: order_detect.nonce,
            },
            success: function(response) {
                if(response.success && response.data) {
					$('#multi-order-preview-'+orderID).text('');
					var dynamicId = 'multi-order-preview-'+orderID

					$('<style>')
						.prop('type', 'text/css')
						.html('#' + dynamicId + '::before { font-family: Dashicons !important; content: "\\f164" !important; }')
						.appendTo('head');
                    $('#multi-order-preview-'+orderID).after(response.data.html);
                }else{
					$('#multi-order-preview-'+orderID).hide();
				}
                 currentIndex++;
                if (currentIndex < orderIds.length) {
                    loadOrder(orderIds[currentIndex]);
                }
            },
            error: function() {
                console.log('Error loading order');
            }
        });
    }

    if (orderIds.length > 0) {
        loadOrder(orderIds[currentIndex]);
    }

	$(document).on('click', '.fetch-courier-score-report', function(e) {
		let button = $(this);
		let orderID = $(this).data('order-id');
		let type = $(this).data('type');
		let result_div = $("#courier-score-preview-" + orderID);
		$.ajax({
			url: order_detect.ajax_url,
			type: 'POST',
			dataType: 'json',
			data: {
				action: type == 'sms' ? 'load_courier_scores_by_phone_sms_list' : 'load_courier_scores_by_phone',
				order_id: orderID,
				security: order_detect.nonce,
				phone_number: $(this).data('phone_number')
			},
			beforeSend: function() {
                button.attr('disabled', true);
                button.text('Loading...');
			},
			success: function(response) {
				if (response.success) {
					result_div.html(response.data);
					button.hide();
				} else {
					let errorMessage = response.data && response.data.message ? response.data.message : "No data found.";
					result_div.html(errorMessage);
				}
			},
			error: function(e, textStatus, errorThrown) {
				console.log('Error loading order');
				console.log('Error Status: ' + textStatus);       
				console.log('Error Thrown: ' + errorThrown);         
				console.log('Response Text: ' + e.responseText);     
				console.log('Error Object:', e);                   
	
				result_div.html("Error retrieving data.");
			},
			complete: function() {
				button.attr('disabled', false);
			}		
		});
	});	

	var od_courier_container = $('#od-courier-container');
	if (od_courier_container.length) {
		let courierOrderID = od_courier_container.data('order-id');
		let phoneNumber = od_courier_container.data('phone-number');
		$.ajax({
			url: order_detect.ajax_url,
			type: 'POST',
			dataType: 'json',
			data: {
				action: 'load_courier_score_order_details_page',
				order_id: courierOrderID,
				phone_number: phoneNumber,
				security: order_detect.nonce,
			},
			success: function(response) {
				if (response.success && response.data) {
					var courier_details = response.data;
					var score = {
						ALL: 0,
						DELIVERED: 0,
						CANCELLED: 0,
						RATE: 0
					};
					$.each(courier_details, function(courier, report) {
						if ($.isPlainObject(report)) {
							score.ALL += parseInt(report.total) || 0;
							score.DELIVERED += parseInt(report.delivered) || 0;
							score.CANCELLED += parseInt(report.cancelled) || 0;
						}
					});
		
					score.RATE = score.ALL > 0 ? Math.round((score.DELIVERED / score.ALL) * 100) : 0;
					var deliveredWidth = score.ALL > 0 ? Math.round((score.DELIVERED / score.ALL) * 100) : 0;
					var canceledWidth = score.ALL > 0 ? Math.round((score.CANCELLED / score.ALL) * 100) : 0;
		
					var html = '<table>';
					html += '<thead><tr><th>Courier</th><th>Total</th><th>Delivered</th><th>Cancelled</th><th>Success Ratio</th></tr></thead>';
					html += '<tbody>';
		
					// Steadfast row
					html += '<tr>';
					html += '<td class="steadfast"><img src="' + order_detect.assetsURL + '/img/steadfast-logo.svg"></td>';
					html += '<td class="steadfast">' + courier_details.stead_fast.total + '</td>';
					html += '<td class="steadfast blue-fade">' + courier_details.stead_fast.delivered + '</td>';
					html += '<td class="steadfast orange-fade">' + courier_details.stead_fast.cancelled + '</td>';
					html += '<td class="steadfast">' + courier_details.stead_fast.success_rate + '%</td>';
					html += '</tr>';
		
					// RedX row
					html += '<tr>';
					html += '<td class="redx"><img src="' + order_detect.assetsURL + '/img/redx-logo.svg"></td>';
					html += '<td class="redx">' + courier_details.redx.total + '</td>';
					html += '<td class="redx blue-fade">' + courier_details.redx.delivered + '</td>';
					html += '<td class="redx orange-fade">' + courier_details.redx.cancelled + '</td>';
					html += '<td class="redx">' + courier_details.redx.success_rate + '%</td>';
					html += '</tr>';
		
					// Pathao row
					html += '<tr>';
					html += '<td class="pathao"><img src="' + order_detect.assetsURL + '/img/pathao-logo.svg"></td>';
					html += '<td class="pathao">' + courier_details.pathao.total + '</td>';
					html += '<td class="pathao blue-fade">' + courier_details.pathao.delivered + '</td>';
					html += '<td class="pathao orange-fade">' + courier_details.pathao.cancelled + '</td>';
					html += '<td class="pathao">' + courier_details.pathao.success_rate + '%</td>';
					html += '</tr>';
		
					// Paperfly row
					html += '<tr>';
					html += '<td class="paperfly"><img src="' + order_detect.assetsURL + '/img/paperfly-logo.svg"></td>';
					html += '<td class="paperfly">' + courier_details.paper_fly.total + '</td>';
					html += '<td class="paperfly blue-fade">' + courier_details.paper_fly.delivered + '</td>';
					html += '<td class="paperfly orange-fade">' + courier_details.paper_fly.cancelled + '</td>';
					html += '<td class="paperfly">' + courier_details.paper_fly.success_rate + '%</td>';
					html += '</tr>';
		
					// Total row
					html += '<tfoot><tr>';
					html += '<th>Total</th>';
					html += '<th>' + score.ALL + '</th>';
					html += '<th>' + score.DELIVERED + '</th>';
					html += '<th>' + score.CANCELLED + '</th>';
					html += '<th>' + score.RATE + '%</th>';
					html += '</tr></tfoot>';
		
					html += '</tbody></table>';
		
					// Progress bar
					html += '<div class="progress-bar-container">';
					html += '<div class="progress-bar">';
					html += '<div class="progress-bar-delivered" style="width:' + deliveredWidth + '%;">' + deliveredWidth + '%</div>';
					if (canceledWidth > 0) {
						html += '<div class="progress-bar-canceled" style="width:' + canceledWidth + '%;">' + canceledWidth + '%</div>';
					}
					html += '</div></div>';
		
					$('#od-courier-container').html(html);
				} else {
					$('#od-courier-container').html('<p>No delivery details found for this order.</p>');
				}
			},
			error: function(xhr, status, error) {
				console.error('AJAX Error:', status, error);
				let errorMessage = 'Something went wrong';
				if (xhr.responseText) {
					const response = JSON.parse(xhr.responseText);
					if (response.message) {
						errorMessage = response.message;
					}
				}
				console.log(errorMessage); 
			},
			complete: function(response){
				$("#courier-details-loader").fadeOut("slow", function() {
					$(".courier-container").fadeIn("slow");
				});
			}
		});
	}

	$(document).on('click', '#provider-settings-save-btn', function(e) {
		let button = $(this);
		let sms_provider = $("#sms_provider").val();
		let sms_api_key = $("#sms_api_key").val();
		let dianahost_sender_id = $("#dianahost_sender_id").val();
		let data = {};

		if (sms_provider === "" || typeof sms_provider === 'undefined' || sms_api_key === '') {
			$("#sms_provider").focus();
			alert('Please select a SMS Provider and API Key');
			return;
		}

		data = {
			action: 'save_sms_provider_settings',
			sms_provider:sms_provider,
			sms_api_key:sms_api_key,
			dianahost_sender_id:dianahost_sender_id,
			security: order_detect.nonce,
		}

		if( 'dianahost' === sms_provider && dianahost_sender_id === ''){
			alert('Sender Id is required');
			return;
		}

		if( 'dianahost' === sms_provider && dianahost_sender_id !== ''){
			data[dianahost_sender_id] = dianahost_sender_id
		}
	
		$.ajax({
			url: order_detect.ajax_url,
			type: 'POST',
			dataType: 'json',
			data: data,
			beforeSend: function() {
				button.attr('disabled', true);
				button.text('Saving...');
			},
			success: function(response) {
				if (response.success) {
					$('#sms-balance-show').text(response.data.balance);
					showToast(response.data.message);
				} 
			},
			error: function(e, textStatus, errorThrown) {
				console.log('Error loading order');
				console.log('Error Status: ' + textStatus);
				console.log('Error Thrown: ' + errorThrown);
				console.log('Response Text: ' + e.responseText);
				console.log('Error Object:', e);
				showToast(e.responseText);
			},
			complete: function() {
				button.attr('disabled', false);
				button.text('Save');
			}
		});
	});
	
	$(document).on('click', '#otp-settings-save-btn', function(e) {
		let button = $(this);
		let enable_otp = $("#enable_otp").is(':checked');
		let checkout_otp_message = $("#checkout_otp_message").val().trim();

		if (enable_otp) {
			if (!checkout_otp_message) {
				$("#checkout_otp_message").focus();
				return;
			}
		}
	
		$.ajax({
			url: order_detect.ajax_url,
			type: 'POST',
			dataType: 'json',
			data: {
				action: 'save_otp_settings',
				enable_otp: enable_otp ? 1 : 0,
				checkout_otp_message: checkout_otp_message,
				security: order_detect.nonce,
			},
			beforeSend: function() {
				button.attr('disabled', true);
				button.text('Saving...');
			},
			success: function(response) {
				if (response.success) {
					showToast(response.data.message);
				} 
			},
			error: function(e, textStatus, errorThrown) {
				console.log('Error loading order');
				console.log('Error Status: ' + textStatus);
				console.log('Error Thrown: ' + errorThrown);
				console.log('Response Text: ' + e.responseText);
				console.log('Error Object:', e);
				showToast(e.responseText);
			},
			complete: function() {
				button.attr('disabled', false);
				button.text('Save');
			}
		});
	});

	jQuery(document).ready(function($) {
        $('.order-detect-status-checkbox[type=checkbox]').each(function() {
            var messageRow = $(this).closest('tr').next('tr');
            if (this.checked) {
                messageRow.show();
            } else {
                messageRow.hide();
            }
        });

        $('.order-detect-status-checkbox[type=checkbox]').change(function() {
            var messageRow = $(this).closest('tr').next('tr');
            if (this.checked) {
                messageRow.show();
            } else {
                messageRow.hide();
            }
        });
    });

	$(document).on('click', '#order-alerts-save-btn', function(e) {
		let button = $(this);
		let settingsData = {};
		let hasError = false;

		$('.order-detect-status-alert').each(function() {
			let fieldName = $(this).attr('name');
			if ($(this).is('textarea')) {
				settingsData[fieldName] = $(this).val();
				let checkbox = $(this).closest('tr').prev().find('.order-detect-status-checkbox[type=checkbox]');
				if (checkbox.is(':checked') && !settingsData[fieldName]) {
					hasError = true;
					$(this).focus();
					return false;
				}
			}
			if ($(this).is(':checkbox')) {
				settingsData[fieldName] = $(this).is(':checked') ? 1 : 0;
			}
		});

		if (hasError) {
			return;
		}

		$.ajax({
			url: order_detect.ajax_url,
			type: 'POST',
			dataType: 'json',
			data: {
				action: 'save_order_alerts',
				settings: settingsData,
				security: order_detect.nonce,
			},
			beforeSend: function() {
				button.attr('disabled', true);
				button.text('Saving...');
			},
			success: function(response) {
				if (response.success) {
					showToast(response.data.message);
				}
			},
			error: function(e, textStatus, errorThrown) {
				console.log('Error loading order');
				console.log('Error Status: ' + textStatus);
				console.log('Error Thrown: ' + errorThrown);
				console.log('Response Text: ' + e.responseText);
				console.log('Error Object:', e);
				showToast(e.responseText);
			},
			complete: function() {
				button.attr('disabled', false);
				button.text('Save');
			}
		});
	});

	jQuery(document).ready(function($) {
		$('#sms_provider').on('change', function() {
			var selectedOption = $(this).find('option:selected');
			var apiKey = selectedOption.attr('api_key');
			var smsBalance = selectedOption.attr('balance');
			$('#sms_api_key').val(apiKey);
			$('#sms-balance-show').text(smsBalance);
			if( $(this).val() === "dianahost" ){
				$("#order-detect-meta-dianahost_sender_id").show();
			}  else{
				$("#order-detect-meta-dianahost_sender_id").hide();
			}
		});
		$('#sms_provider').trigger('change');
	});
	
	function showToast(text) {
        Toastify({
            text: '<span class="dashicons dashicons-cloud-saved"></span> '+text,
            duration: 1000,
            close: true,
            escapeMarkup: false,
            gravity: "bottom",
            position: "right",
            stopOnFocus: true,
            style: {
              background: "#F3793D",
              color: '#ffff',
            },
            onClick: function(){}
          }).showToast();
          setTimeout(() => {
            document.querySelectorAll('.toast-close img').forEach((img) => {
                img.src = order_detect.assetsURL+"/img/toast-close-button.svg";
            });
            document.querySelectorAll('.toastify').forEach((toast) => {
                toast.classList.add('toastify-bounce');
            });
        }, 0);
    }

	$(document).on('change', '.od_phone_number_status', function(e) {

		let select = $(this);
		let id = select.data('id');
		let status = select.val();

		if( id !== '' ){

			$.ajax({
				url: order_detect.ajax_url,
				type: 'POST',
				dataType: 'json',
				data: {
					action: 'update_phone_number_status',
					id: id,
					is_verified: status,
					security: order_detect.nonce,
				},
				beforeSend: function() {
					select.attr('disabled', true);
				},
				success: function(response) {
					select.prop("disabled",false);
					if (response.success) {
						showToast(response.data.message);
					}
				},
				error: function(e, textStatus, errorThrown) {
					select.prop("disabled",false);
					console.log('Error loading order');
					console.log('Error Status: ' + textStatus);       
					console.log('Error Thrown: ' + errorThrown);         
					console.log('Response Text: ' + e.responseText);     
					console.log('Error Object:', e);
				},
				complete: function() {
					select.prop("disabled",false);
				}		
			});
		}

	});

	
	$(document).on('click', '#upload-invoice-packing-slip-logo', function(e) {
		e.preventDefault();

        var custom_uploader = wp.media({
            title: 'Choose Logo',
            button: {
                text: 'Use this logo'
            },
            multiple: false
        });

		custom_uploader.on('select', function() {
            var attachment = custom_uploader.state().get('selection').first().toJSON();
            $('#invoice-packing-slip-logo').attr('src', attachment.url);
        });

        custom_uploader.open();
	});

	$(document).on('click', '#invoice-packing-slip-save-btn', function(e) {
		let button = $(this);
	
		let enable_invoice = $("#enable_invoice").is(':checked');
		// let enable_packing_slip = $("#enable_packing_slip").is(':checked');
		let logo = $('#invoice-packing-slip-logo').attr('src');
		// let business_name = $("#business_name").val();
		let enable_footer_text = $("#enable_footer_text").is(':checked');
		let footer_text_heading = $("#footer_text_heading").val();
		let delivery_partner = $("#delivery_partner").val();
		let primary_color = $("#primary_color").val();
	
		// Use the TinyMCE API to get the content of the rich text editor
		let footer_text_details = '';
		if (typeof tinyMCE !== 'undefined' && tinyMCE.get('footer_text_details')) {
			footer_text_details = tinyMCE.get('footer_text_details').getContent(); // Get the content from wp_editor
		} else {
			footer_text_details = $("#footer_text_details").val(); // Fallback if TinyMCE is not initialized
		}
	
		$.ajax({
			url: order_detect.ajax_url,
			type: 'POST',
			dataType: 'json',
			data: {
				action: 'save_invoice_packing_slip_settings',
				enable_invoice: enable_invoice ? 1 : 0,
				// enable_packing_slip: enable_packing_slip ? 1 : 0,
				logo: logo,
				// business_name: business_name,
				enable_footer_text: enable_footer_text ? 1 : 0,
				footer_text_heading: footer_text_heading,
				footer_text_details: footer_text_details, // Rich text editor content
				delivery_partner: delivery_partner,
				primary_color: primary_color,
				security: order_detect.nonce,
			},
			beforeSend: function() {
				button.attr('disabled', true);
				button.text('Saving...');
			},
			success: function(response) {
				if (response.success) {
					showToast(response.data.message);
				}
			},
			error: function(e, textStatus, errorThrown) {
				console.log('Error loading order');
				console.log('Error Status: ' + textStatus);
				console.log('Error Thrown: ' + errorThrown);
				console.log('Response Text: ' + e.responseText);
				console.log('Error Object:', e);
				showToast(e.responseText);
			},
			complete: function() {
				button.attr('disabled', false);
				button.text('Save');
			}
		});
	});	

	/* bulk action */
	$("#doaction, #doaction2").on('click',function(e){
		var actionselected=$(this).attr("id").substr(2);
		var action = $('select[name="' + actionselected + '"]').val();
		if($.inArray(action,order_detect.bulk_actions) !== -1 ) 
		{
			e.preventDefault();
			var checked_orders=$('tbody th.check-column input[type="checkbox"]:checked');
			if(0 === checked_orders.length)
			{
				alert('You have to select order(s) first!');
				return false;
			}else
			{
				var order_id_arr=new Array();
				checked_orders.each(function(){
					order_id_arr.push($(this).val());
				});

				var action_url = order_detect.print_action_url + '&type=' + action + '&post=' + (order_id_arr.join(',')) + '&_wpnonce=' + order_detect.nonces.od_packlist + '&wt-pdf-bulk=1';
				od_do_print_document_in_admin_page( action_url, true);	
			}
		}
	});

	if ($.fn.wpColorPicker) {
        $('.od-color-field').wpColorPicker();
    }

})(jQuery);

// Document print button in order edit page.
odhandlePrintButtonClick();
function odhandlePrintButtonClick() {
	document.addEventListener('DOMContentLoaded', function () {
		var printButtons = document.querySelectorAll('.od_pklist_admin_print_document_btn');
		printButtons.forEach(function (button) {
			if (false === button.classList.contains("class-name")) {
				button.addEventListener('click', function (e) {
					e.preventDefault();
					var action_url = this.getAttribute('href');
					if ( window.innerWidth <= 768 ) {
						od_do_print_document_in_admin_page_in_mobile_device( action_url );
					} else {
						od_do_print_document_in_admin_page( action_url );
					}
				});
			}
		});
	});
}

function od_do_print_document_in_admin_page_in_mobile_device( url ) {
	var newWindow = window.open(url, '_blank');
	// Once the new window has loaded, trigger the print dialog
	newWindow.onload = function() {
		newWindow.focus();  // Focus the new window before printing
		newWindow.print();

		// Optionally close the window after printing (mobile browsers may block this)
		setTimeout(function() {
			newWindow.close();
		}, 2000);  // Adjust the delay if necessary
	};
}

function od_do_print_document_in_admin_page( url, is_bulk_print = false, reload_page = false ) {
    var newWindow = window.open('', '_blank');
    if (newWindow) {
        newWindow.document.open();
        newWindow.document.write('Document Generating...');
        newWindow.document.close();
        newWindow.document.body.style.cursor = 'progress';
    }

    var xhr = new XMLHttpRequest();
    xhr.open('GET', url, true);
    xhr.onload = function () {
        if (200 === this.status) {
            var responseText = xhr.responseText;

            if (newWindow) {
                // Inject print styles to remove header/footer
                newWindow.document.open();
                newWindow.document.write(`
                    <html>
                        <head>
                            <title>Document Generating...</title>
                            <style>
                                @media print {
                                    @page {
                                        margin: 0;
                                    }
                                    body {
                                        margin: 1cm;
                                        font-size: 12px;
                                    }
                                    header, footer {
                                        display: none !important;
                                    }
                                }
                            </style>
                        </head>
                        <body>
                            <iframe id="odprintIframe" style="width: 100%; height: 100%; border: none;"></iframe>
                        </body>
                    </html>`);
                newWindow.document.close();
                
                // Continue with iframe handling and print logic...
                var odprintIframe = newWindow.document.getElementById('odprintIframe');
                odprintIframe.style.display = 'none';
                var iframeDoc = odprintIframe.contentDocument || odprintIframe.contentWindow.document;
                iframeDoc.open();
                iframeDoc.write(responseText);
                iframeDoc.close();

                setTimeout(function() {
                    odprintIframe.contentWindow.focus();
                    odprintIframe.contentWindow.print();
                    newWindow.document.body.style.cursor = 'auto';
                    newWindow.close();
                }, 500);
            }
        } else {
            alert('Error loading data.');
        }
    };
    xhr.send();
}
