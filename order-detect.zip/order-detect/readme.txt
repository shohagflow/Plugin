=== Order Detect ===
Contributors: neurodigitalbd
Donate Link: https://neurodigitalbd.com/
Tags: woocommerce, order, detect
Requires at least: 4.4
Tested up to: 6.5.4
WC requires at least: 3.1
WC tested up to: 8.6.0
Requires PHP: 5.6
Stable tag: 1.0.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Secure your store with phone verification, multi-order tracking, and parcel trust scores for smarter order management and reduced fraud.

== Description ==

= ORDER DETECT PLUGIN =

== Changelog ==

= 1.0.3 =
Fixed: print invoice conflict with other print plugins

= 1.0.2 =
Integrate print invoice

= 1.0.0 =
Initial version released 

