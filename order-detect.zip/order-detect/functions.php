<?php

use OrderDetect\Helper;

// Track orders and block device if necessary
function track_order_and_block_device($order_id) {
	if (! Helper::check_license(wp_parse_args(get_option('orderdetect_license')))) {
            return;
        }
    $order = wc_get_order($order_id);
    $device_id = isset($_COOKIE['device_id']) ? $_COOKIE['device_id'] : '';
    $ip_address = $_SERVER['REMOTE_ADDR'];
    $phone_number = $order->get_billing_phone();

    if ($device_id && $ip_address && $phone_number) {
        $blocked_devices_file = plugin_dir_path(__FILE__) . 'blocked-devices.json';

        if (!file_exists($blocked_devices_file)) {
            file_put_contents($blocked_devices_file, json_encode([]));
        }

        $blocked_devices = json_decode(file_get_contents($blocked_devices_file), true);

        if (!isset($blocked_devices[$device_id])) {
            $blocked_devices[$device_id] = ['count' => 0, 'blocked_until' => null, 'phone_number' => $phone_number, 'ip_address' => $ip_address, 'device_id' => $device_id];
        }
        if (!isset($blocked_devices[$ip_address])) {
            $blocked_devices[$ip_address] = ['count' => 0, 'blocked_until' => null, 'phone_number' => $phone_number, 'ip_address' => $ip_address, 'device_id' => $device_id];
        }
        if (!isset($blocked_devices[$phone_number])) {
            $blocked_devices[$phone_number] = ['count' => 0, 'blocked_until' => null, 'phone_number' => $phone_number, 'ip_address' => $ip_address, 'device_id' => $device_id];
        }

        $blocked_devices[$device_id]['count']++;
        $blocked_devices[$ip_address]['count']++;
        $blocked_devices[$phone_number]['count']++;

        $max_orders = get_option('max_orders', 5);
        $block_duration = get_option('block_duration', 60);
		$current_time = current_time('timestamp');
        if ($blocked_devices[$device_id]['count'] >= $max_orders || $blocked_devices[$ip_address]['count'] >= $max_orders || $blocked_devices[$phone_number]['count'] >= $max_orders) {
            $blocked_devices[$device_id]['blocked_until'] = $current_time + ($block_duration * 60);
            $blocked_devices[$ip_address]['blocked_until'] = $current_time + ($block_duration * 60);
            $blocked_devices[$phone_number]['blocked_until'] = $current_time + ($block_duration * 60);
        }

        file_put_contents($blocked_devices_file, json_encode($blocked_devices));
    }
}

// Block device on checkout if necessary
function block_device_on_checkout($data, $errors) {
	if (! Helper::check_license(wp_parse_args(get_option('orderdetect_license')))) {
            return;
        }
    $blocked_devices_file = plugin_dir_path(__FILE__) . 'blocked-devices.json';

    if (!file_exists($blocked_devices_file)) {
        return;
    }

    $blocked_devices = json_decode(file_get_contents($blocked_devices_file), true);
    $device_id = isset($_COOKIE['device_id']) ? $_COOKIE['device_id'] : '';
    $ip_address = $_SERVER['REMOTE_ADDR'];
    $phone_number = $_POST['billing_phone'];

    if (isset($blocked_devices[$device_id]) && isset($blocked_devices[$device_id]['blocked_until']) && time() < $blocked_devices[$device_id]['blocked_until']) {
        $errors->add('blocked_device', 'You have been blocked from placing further orders. Please try again later.');
    }

    elseif (isset($blocked_devices[$ip_address]) && isset($blocked_devices[$ip_address]['blocked_until']) && time() < $blocked_devices[$ip_address]['blocked_until']) {
        $errors->add('blocked_device', 'You have been blocked from placing further orders. Please try again later.');
    }

    elseif (isset($blocked_devices[$phone_number]) && isset($blocked_devices[$phone_number]['blocked_until']) && time() < $blocked_devices[$phone_number]['blocked_until']) {
        $errors->add('blocked_device', 'You have been blocked from placing further orders. Please try again later.');
    }
}

// Set a unique device ID in a cookie if not already set
function set_device_id_cookie() {
    if (!isset($_COOKIE['device_id'])) {
        $device_id = bin2hex(random_bytes(16)); // Generate a random device ID
        setcookie('device_id', $device_id, time() + (365 * 24 * 60 * 60), "/"); // Set cookie for 1 year
    }
}
?>
