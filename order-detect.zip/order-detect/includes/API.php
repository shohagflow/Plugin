<?php
namespace OrderDetect;

class API {

    function __construct() {
        new API\LicenseAPI();
    }

}