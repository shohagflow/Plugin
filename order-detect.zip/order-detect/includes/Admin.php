<?php

namespace OrderDetect;

class Admin {

    function __construct() {
        $main = new Admin\Main();
        new Admin\Menu($main);
        new Admin\SMSLog($main);
        new Admin\PrintHistory($main);
        new Admin\MetaBoxes\WCMetaBoxInvoices();
        new Services\Invoice();
        new Services\PackingSlip();
    }
}
