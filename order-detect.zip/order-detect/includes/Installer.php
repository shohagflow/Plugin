<?php

namespace OrderDetect;

class Installer {

    public function run() {
        $this->add_version();
        $this->create_tables();
    }

    public function add_version() {
        $installed = get_option('orderdetect_installed');

        if (!$installed) {
            update_option('orderdetect_installed', time());
        }

        update_option('orderdetect_version', ORDERDETECT_VERSION);
    }

    public function create_tables() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'od_otp_log';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            phone_number varchar(15) NOT NULL,
            code varchar(6) NOT NULL,
            expires_at datetime NOT NULL,
            is_verified int(1) DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY phone_number (phone_number)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);

        $is_error = empty($wpdb->last_error);
        return $is_error;
    }
}
