<?php
use OrderDetect\Helper;
// অ্যাডমিন পেজে অপশন যোগ করা
// function fraud_blocker_admin_menu() {
//     add_menu_page(
//         'Fraud Blocker Settings',
//         'Fraud Blocker',
//         'manage_options',
//         'fraud-blocker',
//         'fraud_blocker_settings_page'
//     );
// }
// add_action( 'admin_menu', 'fraud_blocker_admin_menu' );

// অ্যাডমিন পেজের HTML
function fraud_blocker_settings_page() {
	 if (! Helper::check_license(wp_parse_args(get_option('orderdetect_license')))) {
            return;
        }
    // সেভ অপশন
    if ( isset( $_POST['save_blocked_data'] ) ) {
        $blocked_ips = isset( $_POST['blocked_ips'] ) ? explode( "\n", sanitize_textarea_field( $_POST['blocked_ips'] ) ) : [];
        $blocked_phones = isset( $_POST['blocked_phones'] ) ? explode( "\n", sanitize_textarea_field( $_POST['blocked_phones'] ) ) : [];

        update_option( 'blocked_ips', array_map( 'trim', $blocked_ips ) );
        update_option( 'blocked_phones', array_map( 'trim', $blocked_phones ) );
        echo '<div class="updated"><p>Settings saved.</p></div>';
    }

    // অপশন পেজের ফর্ম
    $blocked_ips = get_option( 'blocked_ips', [] );
    $blocked_phones = get_option( 'blocked_phones', [] );
    ?>

	<style>
		.notice-warning {
   		 display: none;
		}

	</style>
    <div class="wrap">
        <h1>Fraud Blocker Settings</h1>
        <form method="post">
            <h2>Blocked IPs</h2>
            <textarea name="blocked_ips" rows="5" cols="50"><?php echo implode( "\n", $blocked_ips ); ?></textarea>
            <h2>Blocked Phone Numbers</h2>
            <textarea name="blocked_phones" rows="5" cols="50"><?php echo implode( "\n", $blocked_phones ); ?></textarea>
            <br><br>
            <input type="submit" name="save_blocked_data" class="button button-primary" value="Save">
        </form>
    </div>
    <?php
}
