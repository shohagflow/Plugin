<?php

namespace OrderDetect;

class Frontend {
    
    function __construct() {

        if( ! Helper::check_license(wp_parse_args(get_option('orderdetect_license'))) ) {
            return;
        }

        new Frontend\StoreFront();
    }
}
