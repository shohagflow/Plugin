<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php _e('Invoice', 'order-detect'); ?>_<?php echo esc_html($this->order->get_order_number()); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">  
    <style>

        html, body {
            height: 100%;
            margin: 0;
            padding: 0;
            font-family: 'Roboto', sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 800px;
        }

        .od-invoice-container{
            padding-top: 20px;
            padding-bottom: 20px;
            padding-left: 20px;
            padding-right: 20px;
            min-height: 100vh;
            box-sizing: border-box;
            /* display: flex;
            flex-direction: column;
            justify-content: space-between; */
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 5px;
        }
        .logo {
            flex: 1;
            text-align: center;
        }
        .neuro {
            width: 100px;
            text-align: right;
        }
        .bill-info {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }
        .bill-to, .order-info {
            flex: 1;
        }
        .bill-to h3 {
			font-weight: 600;
			color: #000000;
            font-family: 'Roboto';
            margin:0 !important;
        }
        .bill-to p{
			font-weight: 400;
			color: #000000;
            font-family: 'Roboto';
            margin:0 !important;
        }
        .order-info {
            text-align: right;
        }
        .order-info p{
		    font-weight: 400;
			color: #000000;
            font-family: 'Roboto';
            margin:0;
        }
		
		.order-info p strong{
			font-weight: 700;
			color: #000000;
            font-family: 'Roboto';
         }
		
		.table_container {
			border-bottom: 1px solid #ccc;
			border-radius: 8px;
			overflow: hidden; /* This ensures the rounded corners are visible */
		}
		
        table {
            width: 100%;
            border-collapse: collapse;
			border-spacing: 0;
        }

        th, td {
            padding: 4px 8px;
            text-align: center;
            font-weight: 400;
            font-size: 12px;
			border-left: 1px solid #ccc;
            border-right: 1px solid #ccc;
        }
		
        th {
            font-family: 'Roboto';
			font-weight: 400;
            background: #fff;
            color: #fff;
        }

		th:first-child{
			border-left: 1px solid #000;
			border-top-left-radius: 5px;
		}

		th:last-child{
			border-top-right-radius: 5px;
			border-right: 1px solid #000;
		}

        table tr:nth-child(even) {
            background-color: #F8F8F8;
        }
		td:first-child {
	        border-bottom-left-radius: 5px;
         }

		td:last-child {
	        border-bottom-right-radius: 5px;
         }
        .item-name {
            font-family: 'Roboto';
			font-weight: 400;
			color: #000;
        }
        .item-size {
            font-size: 0.9em;
            color: #000;
			text-align: left;
        }
        .totals {
            text-align: right;
            font-weight: 400;
        }
        .totals p {
            margin:0;
        }
        .sub-total, .grand-total, .due-amount {
            background-color: #000;
            color: #fff;
            padding: 5px;
            font-weight: 400;
			font-family: 'Roboto';
        }
        .grand-total{
            background-color: transparent;
            color: #333;
            border-top-color: #ddd;
        }
        .delivery-charge {
            padding: 5px;
        }
        .logo img {
            width: 50px;
            height: auto;
        }
        @media print {
            body{ -webkit-print-color-adjust:exact; color-adjust:exact;padding-top:0;
                padding-bottom:0; }
            @page { size:auto; margin: 0mm; margin-top: 0;
                margin-bottom: 0;}
            body,html{ margin:0; background-color: #FFFFFF; }
            table tr, table tr td{ page-break-inside: avoid; }
        }
        .product-info{
            display:flex;
        }
        .product-attributes{
            margin-left: 10px;
        }
        .invoice-footer{
            display: block;
		    margin-top: 10px;
        }
        .invoice-footer-top h2{
            font-size: 18px;
			font-family: 'Roboto';
			font-weight: 600;
			margin: 0 !important;
        }
        .invoice-footer-body p{
            font-size: 12px;
			font-weight: 400;
			color: #000000;
            font-family: 'Roboto';
			margin: 0 !important;
        }
        .invoice-footer-body ul li,
        .invoice-footer-body ul li a,
        .invoice-footer-body a,
        .invoice-footer-body ol li,
        .invoice-footer-body ol li a{
            font-size: 12px;
            font-weight: 400;
        }
    </style>
    <?php 
        if( ! empty( $this->settings['primary_color'] ) ) {
            echo "<style>";
            echo '
                .sub-total, .due-amount,
                th {
                    background-color: '.$this->settings['primary_color'].';
                }
            ';
            echo "</style>";

        }
    ?>
</head>
<body>
    <div class="od-invoice-container">
        <div class="header">
            <div class="logo" style="flex: 1; text-align: center;">
                <img src="<?php echo esc_url($this->settings['invoice_packing_slip_logo']); ?>" alt="Logo" style="max-width: 100%; height: auto;">
            </div>
            <div class="neuro" style="text-align: right;">
                <img src="<?php echo ORDERDETECT_ASSETS . "/img/neuro-digital.png" ?>" alt="NEURO Digital Logo" style="width: 100px; height: auto;">
            </div>
        </div>

        <div class="bill-info">
            <div class="bill-to">
                <h3>BILL TO:</h3>
                <p>
                    <?php echo esc_html( $this->order->get_billing_first_name() . ' ' . $this->order->get_billing_last_name() ); ?><br>
                    <?php echo esc_html( $this->order->get_billing_phone() ); ?><br>
                    <?php echo esc_html( $this->order->get_billing_address_1() ); ?>
                    <?php echo esc_html( $this->order->get_billing_city() . ', ' . $this->order->get_billing_state() . ', ' . $this->order->get_billing_country() ); ?>
                    <?php echo esc_html( $this->order->get_billing_postcode() ); ?>
                </p>
            </div>
            <div class="order-info">
                <p>Order ID: <strong><?php echo esc_html( $this->order->get_order_number() ); ?></strong></p>
                <p>Courier: <strong><?php echo esc_attr( $this->settings['delivery_partner'] ); ?></strong></p>
                <?php 
                    $consignment_id = ( get_post_meta( $this->order->get_id(), 'steadfast_consignment_id', true ) ) ? esc_html( get_post_meta( $this->order->get_id(), 'steadfast_consignment_id', true ) ) : '';
                ?>
                <p>Courier ID: <strong><?php echo $consignment_id; ?></strong></p>
                <p>Date: <strong><?php echo esc_html( wc_format_datetime( $this->order->get_date_created() ) ); ?></strong></p>
            </div>
        </div>
	  <div class="table_container">
        <table>
            <thead>
                <tr>
                    <th>SL</th>
                    <th>Item Name</th>
                    <th>SKU</th>
                    <th>Unit Price</th>
                    <th>Quantity</th>
                    <th>Amount</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                    $items = $this->order->get_items();
                    $i = 1;
                    foreach ($items as $item_id => $item) : 
                        $product = $item->get_product();
                        $quantity = $item->get_quantity();
                        $product_name = $item->get_name();
                        $product_price = $item->get_total();
                        $product_sku = $product->get_sku();
                        $unit_price = wc_price($product->get_price());
                        $total_price = wc_price($item->get_total());
                        $product_image_url = wp_get_attachment_image_url($product->get_image_id(), 'thumbnail');
                        if (!$product_image_url) {
                            $product_image_url = '/path/to/placeholder-image.jpg';
                        }
                ?>
                <tr>
                    <td><?php echo $i; ?></td>
                    <td>
                        <div class="product-info">
                            <img src="<?php echo esc_url($product_image_url); ?>" alt="<?php echo esc_attr($product_name); ?>" style="width: 40px; height: auto;">
                            <div class="product-attributes">
                                <div class="item-name"><?php echo esc_html($product_name); ?></div>
                                <div class="item-size">
                                <?php
                                // First, ensure you have access to the product object and the $item_id for the order item
                                if ( isset( $product ) && isset( $item_id ) ) {
                                    // Check if the product is a variable product (with variations)
                                    if ( $product->is_type( 'variable' ) ) {
                                        // Get all available attributes for the product
                                        $attributes = $product->get_attributes();

                                        // Loop through all the product attributes
                                        foreach ( $attributes as $attribute_slug => $attribute ) {
                                            // If this is a 'pa_' attribute (a product attribute, like size or color)
                                            if ( strpos( $attribute_slug, 'pa_' ) === 0 ) {
                                                // Get the value selected for this attribute in the order item
                                                $selected_value = wc_get_order_item_meta( $item_id, $attribute_slug, true );

                                                // If the attribute has a selected value, display it
                                                if ( ! empty( $selected_value ) ) {
                                                    // Get the attribute label (e.g., "Size," "Color," etc.)
                                                    $attribute_label = wc_attribute_label( $attribute_slug, $product );

                                                    // Output the label and the selected value
                                                    echo '<span>' . esc_html( $attribute_label ) . ': ' . esc_html( $selected_value ) . '</span>';
                                                }
                                            }
                                        }
                                    } else {
                                        // Handle simple products with attributes (non-variable products)
                                        $attributes = $product->get_attributes();
                                        foreach ( $attributes as $attribute_slug => $attribute ) {
                                            if ( strpos( $attribute_slug, 'pa_' ) === 0 ) {
                                                // Get the selected attribute value for simple products
                                                $selected_value = wc_get_order_item_meta( $item_id, $attribute_slug, true );

                                                if ( !empty( $selected_value ) ) {
                                                    // Fetch attribute label for simple products
                                                    $attribute_label = wc_attribute_label( $attribute_slug, $product );
                                                    echo '<span>' . esc_html( $attribute_label ) . ': ' . esc_html( $selected_value ) . '</span>';
                                                }
                                            }
                                        }
                                    }
                                }
                                ?>
                            </div>

                            </div>
                        </div>
                    </td>
                    <td><?php echo esc_html($product_sku); ?></td>
                    <td><?php echo $unit_price; ?></td>
                    <td><?php echo esc_html($quantity); ?></td>
                    <td><?php echo $total_price; ?></td>
                </tr>
                <?php $i++; ?>
                <?php endforeach; ?>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td colspan="3" style="padding:0px;">
                        <div class="totals">
                            <p class="sub-total" style="display:flex; justify-content: space-between;">
                                <span>Sub Total:</span> <span><?php echo wc_price( $this->order->get_subtotal() ); ?></span>
                            </p>
                            <p class="delivery-charge" style="display:flex; justify-content: space-between;background-color: #F8F8F8;">
                                <span>Delivery Charge: </span><span><?php echo wc_price( $this->order->get_shipping_total() ); ?></span>
                            </p>
                            <p class="grand-total" style="display:flex; justify-content: space-between;border-top: 1px solid #ddd; ">
                                <span>Grand Total: </span><span><?php echo wc_price( $this->order->get_total() ); ?></span>
                            </p>
                            <p class="due-amount" style="display:flex; align-items: center; justify-content: space-between;border-top: 1px solid #ddd; ">
                                <span>Due Amount: </span><span><?php echo wc_price( $this->order->get_total() ); ?></span>
                            </p>
                        </div>

                    </td>
                </tr>
            </tbody>
        </table>
      </div>
        <?php if( $this->settings['enable_footer_text'] == 1 ): ?>
        <div class="invoice-footer">
            <div class="invoice-footer-top">
                <h2><?php echo esc_attr($this->settings['footer_text_heading']); ?></h2>           
            </div>
            <div class="invoice-footer-body">
				<p><?php echo $this->settings['footer_text_details']; ?> </p>
            </div>
        </div>
        <?php endif; ?>
    </div>
</body>
</html>