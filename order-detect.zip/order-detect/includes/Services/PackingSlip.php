<?php

namespace OrderDetect\Services;

use OrderDetect\Helper;
use WC_Order;
use Dompdf\Dompdf;
use Dompdf\Options;

class PackingSlip {

    private $order;
    private $settings;
	private Dompdf $dompdf;
    private Options $options;

    public function __construct() {

		$this->options = new Options();
        $this->options->set('isPhpEnabled', true);
		$this->options->set('isHtml5ParserEnabled', true);
        $this->options->set('enableCssFloat', true);
        $this->options->set('isRemoteEnabled', true);
        $this->options->set('defaultFont', 'dejavu Sans');
        $this->options->set('fontHeightRatio','1.0');
        $this->options->set('enable_font_subsetting', true);
        $this->options->set('isFontSubsettingEnabled',true);

        // Create a new Dompdf instance with the options
        $this->dompdf = new Dompdf($this->options);
        $this->dompdf->set_option('isRemoteEnabled', true);
		$this->dompdf->setPaper( 'A4', 'portrait');

        $this->settings = wp_parse_args(get_option('orderdetect_settings', array(
            'sms_provider' => 'greenweb',
            'sms_api_key' => array(
                'greenweb' => '',
                'alpha' => '',
                'dianahost' => ''
            ),
            'enable_otp' => 0,
            'checkout_otp_message' => '',
            'dianahost_sender_id' => '',
            'enable_invoice' => 0,
            'enable_packing_slip' => 0,
            'invoice_packing_slip_logo' => '',
            'business_name' => '',
            'enable_footer_text' => 0,
            'footer_text_heading' => '',
            'footer_text_details' => '',
            'delivery_partner' => '',
            'primary_color' => '#000'
        )));

		add_action( 'od_print_doc', array( $this, 'print_it' ), 10, 2 );
    }

    public function add_bulk_print_buttons( $actions ) {
		$actions['print_packinglist']=__('Print Packing slip','print-invoices-packing-slip-labels-for-woocommerce');
		return $actions;
	}

    /* 
	* Print_window for packinglist
	* @param $orders : order ids
	*/    
    public function print_it( $order_ids, $action ) {

        if("print_packingslip" === $action || "download_packingslip" === $action)
        {   
            if( ! is_array( $order_ids ) ) {
                return;
            }    

            if( count( $order_ids ) > 1 ) {
                sort( $order_ids );
            }

            $pdf_name = 'packing_slip_';
            $html = $this->generate_order_template( $order_ids, $pdf_name );

            if( "download_packingslip" === $action ) {
                $this->generate_template_pdf( $html, $pdf_name );
            } else {
                echo $html;
            }

            exit();
        }

    }
    public function generate_order_template( $orders, $pdf_name ) {

    	$html = '';
    	$out = '';
        $out_arr = array();

        foreach ( $orders as $order_id ) {

            $order = wc_get_order( $order_id );
            $order_packages = null;

            // $order_packages = $box_packing->wf_pklist_create_order_single_package( $order );
            // $number_of_order_package = count( $order_packages );

            // if( ! empty( $order_packages ) ) {
            //     $order_pack_inc = 0;
            //     foreach ( $order_packages as $order_package_id => $order_package ) {
            //         $order_pack_inc++;
            //         $order = wc_get_order( $order_id );
            //         $out_arr[] = $this->generate_template_html( $html, $order, $box_packing, $order_package );			            
            //     }

            // } else {
            //     $no_item_error_message = __("Unable to print packling slip. Please check the items in the order.",'print-invoices-packing-slip-labels-for-woocommerce');
            //     if( 'print_packingslip' === $action ) {
                    
            //         header('Content-Type: text/plain');
            //         $no_item_error_message = htmlspecialchars($no_item_error_message, ENT_QUOTES, 'UTF-8');
            //         echo $no_item_error_message;
            //         exit();

            //     } else {
            //         wp_die( $no_item_error_message, "", array() );
            //     }
            // }

            $out_arr[] = $this->generate_template_html( $order );

        }

        $out = implode('<p class="pagebreak"></p>',$out_arr).'<p class="no-page-break"></p>';

    	return $out;
    }

    public function generate_template_html( $order ) {

		$this->order = $order;
        if ( ! $this->order ) {
            wp_die(__('Invalid order.', 'order-detect'));
        }

    	$out = '';
		ob_start();
        $order_data = $this->order->get_data();
        $items = $this->order->get_items();
        include __DIR__ . '/templates/packing-template.php';
        $out = ob_get_clean();
		return $out;
    }

    public function generate_template_pdf( $html, $pdf_name ) {

        $this->dompdf->loadHtml( $html );
		$this->dompdf->render();
		$this->dompdf->stream( $pdf_name.$this->order->get_id().'.pdf', array( 'Attachment' => 1 ) );

		return true;

    }
    
}