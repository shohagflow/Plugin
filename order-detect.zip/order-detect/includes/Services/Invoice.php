<?php

namespace OrderDetect\Services;

use OrderDetect\Helper;
use WC_Order;
use Dompdf\Dompdf;
use Dompdf\Options;

class Invoice {
    private $order;
    private $settings;
	private Dompdf $dompdf;
    private Options $options;

    public function __construct() {

		$this->options = new Options();
        $this->options->set('isPhpEnabled', true);
		$this->options->set('isHtml5ParserEnabled', true);
        $this->options->set('enableCssFloat', true);
        $this->options->set('isRemoteEnabled', true);
        $this->options->set('defaultFont', 'dejavu Sans');
        $this->options->set('fontHeightRatio','1.0');
        $this->options->set('enable_font_subsetting', true);
        $this->options->set('isFontSubsettingEnabled',true);

        // Create a new Dompdf instance with the options
        $this->dompdf = new Dompdf($this->options);
        $this->dompdf->set_option('isRemoteEnabled', true);
		$this->dompdf->setPaper( 'A4', 'portrait');

        $this->settings = wp_parse_args(get_option('orderdetect_settings', array(
			'sms_provider' => 'greenweb',
			'sms_api_key' => array(
				'greenweb' => '',
				'alpha' => '',
				'dianahost' => ''
			),
			'enable_otp' => 0,
			'checkout_otp_message' => '',
			'dianahost_sender_id' => '',
			'enable_invoice' => 0,
			'enable_packing_slip' => 0,
			'invoice_packing_slip_logo' => '',
			'business_name' => '',
			'enable_footer_text' => 0,
			'footer_text_heading' => '',
			'footer_text_details' => '',
            'delivery_partner' => '',
            'primary_color' => '#000'
		)));

		add_action( 'od_print_doc', array( $this, 'print_it' ), PHP_INT_MAX, 2 );
        add_action( 'init', array( $this, 'print_window' ), PHP_INT_MAX );
		add_filter( 'bulk_actions-edit-shop_order', array( $this, 'add_bulk_print_buttons' ), PHP_INT_MAX); 
		add_filter( 'bulk_actions-woocommerce_page_wc-orders', array( $this,'add_bulk_print_buttons' ), PHP_INT_MAX);

    }

	public function add_bulk_print_buttons( $actions ) {
		$settings = wp_parse_args(get_option('orderdetect_settings', array(
            'sms_provider' => 'greenweb',
            'sms_api_key' => array(
                'greenweb' => '',
                'alpha' => '',
                'dianahost' => ''
            ),
            'enable_otp' => 0,
            'checkout_otp_message' => '',
            'dianahost_sender_id' => '',
            'enable_invoice' => 0,
            'enable_packing_slip' => 0,
            'invoice_packing_slip_logo' => '',
            'business_name' => '',
            'enable_footer_text' => 0,
            'footer_text_heading' => '',
            'footer_text_details' => '',
            'delivery_partner' => '',
            'primary_color' => '#000'
        )));

		if( isset($settings['enable_invoice']) && 1 == $settings['enable_invoice'] ) {
			$actions['od_print_invoice']= __('Print Invoices','order-detect');
			// $actions['od_download_invoice']= __('Download Invoices','order-detect');
		}

		return $actions;
	}

    /**
	* 	Print_window for invoice
	* 	@param $orders : order ids
	*	@param $action : (string) download/preview/print
	*/    
    public function print_it( $order_ids, $action ) {
    	if( "od_print_invoice" === $action || "od_download_invoice" === $action ) {

    		if( ! is_array( $order_ids ) ) {
    			return;
    		}

            if( count( $order_ids ) > 1 ) {
                sort( $order_ids );
            }

            $pdf_name = 'Invoice_';
            if( "od_download_invoice" === $action ) {
                $html = $this->generate_order_template( $order_ids, $pdf_name );
                $this->generate_template_pdf( $html,  $pdf_name );

            } else {
				ob_start();
                $html = $this->generate_order_template( $order_ids, $pdf_name, $action );
                ob_end_clean();
                echo $html;
            }

	        exit();
    	}
    }

	public function generate_order_template( $orders, $html = "", $action = "" ) {

		$number_of_orders = count( $orders );
    	$order_inc = 0;
    	$out = '';

		foreach( $orders as $order_id ) {
    		$order_inc++;
    		$out .= $this->generate_order_template_for_single_order( $order_id, $html, $action );

			$print_history = get_post_meta( $order_id, 'print_history', true );
			if ( ! is_array( $print_history ) ) {
				$print_history = [];
			}
			$user_id = get_current_user_id();
			$current_time = current_time( 'mysql' );
			$print_history[] = [
				'user_id' => $user_id,
				'time'    => $current_time,
			];
			update_post_meta( $order_id, 'print_history', $print_history );
    	}
		
		if( 1 < $number_of_orders && ( "od_print_invoice" === $action ) ) {
			$out	= str_replace('</body>','<div class="pagebreak"></div></body>',$out);
		}
		
    	return $out;
	}

	public function generate_order_template_for_single_order( $order_id, $html, $action ) {

		$this->order = wc_get_order( $order_id );
        if (! $this->order ) {
            wp_die(__('Invalid order.', 'order-detect'));
        }

    	$out = '';
		ob_start();

        $order_data = $this->order->get_data();
        $items = $this->order->get_items();
        include __DIR__ . '/templates/invoice-template.php';
        $out = ob_get_clean();
		return $out;
    }

    public function print_window() {
		if ( isset( $_REQUEST['print_od_packinglist']) ) {
		    $this->print_document_from_the_admin_link();
        }
    }

    public function print_document_from_the_admin_link() {
		$nonce	= isset( $_REQUEST['_wpnonce'] ) ? sanitize_text_field( $_REQUEST['_wpnonce'] ) : '';
        $orders	= array();
		$not_allowed_msg = __( 'You are not allowed to view this page.', 'order-detect' );
		$not_allowed_title = __( 'Access denied !!!.', 'order-detect' );

        if( ! ( wp_verify_nonce( $nonce, 'order-detect' ) ) ) {
			self::od_pklist_safe_redirect_or_die( null, $not_allowed_msg );	
		} else {
			$user_access	= apply_filters('od_pklist_document_access_for_user_role',true);
			if ( ! $user_access ) {
				self::od_pklist_safe_redirect_or_die( null, $not_allowed_title );	
			}
			$orders = explode(',', sanitize_text_field($_REQUEST['post']));
		}

        // when doing the bulk print without permission
		if( count( $orders ) > 1 ) {
			if( ! self::check_role_access() ) {
				self::od_pklist_safe_redirect_or_die( '', __("You are not allowed to do this action","order-detect") );
			}
		}

		if (1 === count( $orders ) ) {
			$order = wc_get_order( $orders[0] );
			if ( empty( $order ) ) {
				self::od_pklist_safe_redirect_or_die( null, __( 'There is no order with this id', 'order-detect' ) );
			} else {
				if ( ! self::check_role_access() ) {
					$order_user_id	= $order->get_user_id();
					$user_id 		= get_current_user_id();
					if( $user_id !== $order_user_id ) {
						$i = 0;
						$order_items = $order->get_items();
						if( ! empty( $order_items ) ) {
							foreach ($order_items as $item_id => $item) {
								if( method_exists( $item, 'get_product')  ) {
									$product = $item->get_product();
									if ( $product ) {
										$product_id	= $product->get_id();
										$vendor_id	= (int) get_post_field('post_author', $product_id);
										if($user_id !== $vendor_id){
											self::od_pklist_safe_redirect_or_die( null, __( 'It seems this order is not yours', 'order-detect' ) );
											break;
										}
									} else {
										// increase the deleted product count.
										$i++;
									}
								} else {
									// increase the deleted product count.
									$i++;
								}
							}

							if( $i === count( $order_items ) ) {
								// all the items in the order were deleted.
								self::od_pklist_safe_redirect_or_die( null, __( 'It seems the products in this order were removed, we cannot proceed this actoin now.', 'order-detect' ) );
							}
						} else {
							// Order does not have the items.
							self::od_pklist_safe_redirect_or_die( null, __( 'There is no items in this order.', 'order-detect' ) );
						}
					} else if ( 0 === $user_id) { // Guest user is not allowed to print/download through the admin link
						self::od_pklist_safe_redirect_or_die( null, __( 'You are not allowed to do this action', 'order-detect' ) );
					}
				}
			}

			if( isset( $order ) && !empty( $order ) ) {
				// clear the variable to save the memory
				unset($order);
			}
		}

		if( ! empty( $orders ) && is_array( $orders ) ) {

			$orders = array_values( array_filter( $orders ) );
			$orders = $this->verify_order_ids( $orders );

			if( count( $orders ) > 0 ) {

				remove_action( 'wp_footer', 'wp_admin_bar_render', 1000 );
				$action = (isset( $_GET['type'] ) ? sanitize_text_field( $_GET['type'] ) : '');

				// Set the option to show the banner after the bulk print
				$document_actions_for_banner = array(
					'od_print_invoice',
					'od_download_invoice',
					'print_od_packinglist',
					'download_od_packinglist',
				);

				// Removes the WooCommerce filter, that is validating the quantity to be an int
				remove_filter('woocommerce_stock_amount', 'intval');

				// Add a filter, that validates the quantity to be a float
				add_filter('woocommerce_stock_amount', 'floatval');
				
				//action for modules to hook print function
				do_action( 'od_print_doc', $orders, $action );

				// remove the filter from rendering html
				remove_filter('woocommerce_stock_amount', 'floatval');
				add_filter('woocommerce_stock_amount', 'intval');
			}
		}
		exit();

    }

    /**
	* @since 2.5.9
	* Is allowed to print
	*/
	public static function check_role_access() {
		$admin_print_role_access = array( 'manage_options', 'manage_woocommerce' );
    	$admin_print_role_access = apply_filters( 'od_pklist_alter_admin_print_role_access', $admin_print_role_access );  
    	$admin_print_role_access = ( ! is_array( $admin_print_role_access ) ? array() : $admin_print_role_access);
    	$is_allowed = false;
    	foreach( $admin_print_role_access as $role ) {
    		if( current_user_can( $role ) ) {
    			$is_allowed=true;
    			break;
    		}
    	}
    	return $is_allowed;
	}

    /**
	* Check for valid order ids
	* @since 2.5.4
	* @since 2.5.7 Added compatiblity for `Sequential Order Numbers for WooCommerce`
	*/
    public static function verify_order_ids($order_ids) {
    	$out = array();
    	foreach ( $order_ids as $order_id ) {
    		if( false === wc_get_order( $order_id ) ) {

    			$order_data=wc_get_orders(
    				array(
    					'limit' => 1,
    					'return' => 'ids',
    					'meta_query' => array(
    						'key'=>'_order_number',
    						'value'=> $order_id,
    					)
    				)
				);
    			if( false !== $order_data && is_array( $order_data ) && 1 === count( $order_data ) ) {
    				$order_id = (int) $order_data[0];
    				if( $order_id > 0 && false !== wc_get_order( $order_id ) ) {
    					$out[] = $order_id;
    				}
    			}
    		} else {
    			$out[] = $order_id;
    		}
    	}
    	return $out;
    }

    /**
	 * Safe redirect to the page or die
	 * 
	 * @since 4.2.0
	 * @param string $url
	 * @param string $message
	 * @return void
	 */
	public static function od_pklist_safe_redirect_or_die( $url = '', $message = '' ) {
		if ( ! empty( $url ) ) {
			wp_safe_redirect( $url );
			exit;
		} else {
			wp_die( $message );
		}
	}

	public function generate_template_pdf( $html, $pdf_name ) {

		$pdf_name = $pdf_name.$this->order->get_id().'.pdf';
		$this->dompdf->loadHtml( $html );
		$this->dompdf->render();
		$this->dompdf->stream( $pdf_name, array( 'Attachment' => 1 ) );
		return true;
	}

}