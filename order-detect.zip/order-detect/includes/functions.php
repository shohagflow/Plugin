<?php
use OrderDetect\Helper;

if ( ! function_exists( 'add_multi_order_tracking_column_header' ) ) {
    function add_multi_order_tracking_column_header( $columns ) {
        $new_columns = array();

        foreach ( $columns as $column_name => $column_info ) {
            $new_columns[ $column_name ] = $column_info;
            if ( 'order_number' === $column_name ) {
                $new_columns['order_track'] = __( 'Multi-Order Track', 'order-detect' );
            }
        }
        return $new_columns;
    }
}

if( Helper::check_license( wp_parse_args( get_option('orderdetect_license') ) ) ) {
    add_filter( 'manage_edit-shop_order_columns', 'add_multi_order_tracking_column_header', 20 );
    add_filter( "manage_woocommerce_page_wc-orders_columns", 'add_multi_order_tracking_column_header', 20 );
    add_filter( "manage_edit-woocommerce_page_wc-orders_columns", 'add_multi_order_tracking_column_header', 20 );
}

if ( ! function_exists( 'get_orders_by_phone_number' ) ) {
    function get_orders_by_phone_number( $phone_number ) {
        global $wpdb;

        $query_one = "
            SELECT posts.ID
            FROM {$wpdb->prefix}posts AS posts
            INNER JOIN {$wpdb->prefix}postmeta AS meta ON posts.ID = meta.post_id
            WHERE posts.post_type = 'shop_order'
            AND posts.post_status IN ('wc-pending', 'wc-processing', 'wc-on-hold', 'wc-completed', 'wc-cancelled', 'wc-refunded', 'wc-failed')
            AND meta.meta_key = '_billing_phone'
            AND meta.meta_value LIKE %s
            ORDER BY posts.ID DESC
        ";

        $query_two = "
            SELECT posts.ID
            FROM {$wpdb->prefix}posts AS posts
            INNER JOIN {$wpdb->prefix}wc_order_addresses AS meta ON posts.ID = meta.order_id
            WHERE posts.post_type = 'shop_order_placehold'
            AND meta.address_type = 'billing'
            AND meta.phone LIKE %s
            ORDER BY posts.ID DESC
        ";

        $orders_data = search_phone_number_multiple_order( $query_one, $phone_number );
        if( empty( $orders_data ) ){
            $orders_data = search_phone_number_multiple_order( $query_two, $phone_number );
        }

        $orders = [];
        foreach ($orders_data as $order_data) {
            $orders[] = new \WC_Order($order_data);
        }

        return $orders;
    }
}

if ( ! function_exists( 'search_phone_number_multiple_order' ) ) {
    function search_phone_number_multiple_order( $query, $phone_number ) {
        global $wpdb;

        $prepared_query = $wpdb->prepare($query, '%' . $wpdb->esc_like($phone_number) . '%');
        $order_ids = $wpdb->get_col($prepared_query);

        if ( empty( $order_ids ) ) {
            return [];
        }

        $placeholders = implode(', ', array_fill(0, count($order_ids), '%d'));
        $orders_query = "
            SELECT *
            FROM {$wpdb->prefix}posts
            WHERE ID IN ($placeholders)
            ORDER BY ID DESC
        ";
        $prepared_orders_query = $wpdb->prepare($orders_query, ...$order_ids);
        $orders_data = $wpdb->get_results($prepared_orders_query);

        return $orders_data;

    }
}

if ( ! function_exists( 'multi_order_tracking_column_content' ) ) {
    function multi_order_tracking_column_content( $column, $order ) {

        if ( 'order_track' !== $column ) {
            return;
        }

        if ( $order instanceof \WC_Order ) {
            $id = $order->get_id();
        } else {
            $id = $order;
        }
        
        if ( 'order_track' === $column ) {
            echo '<a href="#" id="multi-order-preview-'.$id.'" class="multi-order-preview" data-order-id="'.$id.'" title="Multi-Order Track">Loading...</a>';
        }
    }
}

if( Helper::check_license( wp_parse_args( get_option('orderdetect_license') ) ) ) {
    add_action( 'manage_shop_order_posts_custom_column', 'multi_order_tracking_column_content', 10, 2 );
    add_action( "manage_woocommerce_page_wc-orders_custom_column", 'multi_order_tracking_column_content', 10, 2 );
    add_action( "manage_woocommerce_page_wc-orders_posts_custom_column", 'multi_order_tracking_column_content', 10, 2 );
}


if ( ! function_exists( 'add_courier_score_column_header' ) ) {
    function add_courier_score_column_header( $columns ) {
        $new_columns = array();

        foreach ( $columns as $column_name => $column_info ) {
            $new_columns[ $column_name ] = $column_info;
            if ( 'order_status' === $column_name ) {
                $new_columns['courier_score'] = __( 'Courier Score', 'order-detect' );
            }
        }
        return $new_columns;
    }
}

if( Helper::check_license( wp_parse_args( get_option('orderdetect_license') ) ) ) {
    add_filter( 'manage_edit-shop_order_columns', 'add_courier_score_column_header', 20 );
    add_filter( "manage_woocommerce_page_wc-orders_columns", 'add_courier_score_column_header', 20 );
    add_filter( "manage_edit-woocommerce_page_wc-orders_columns", 'add_courier_score_column_header', 20 );
}

if ( ! function_exists( 'courier_score_column_content' ) ) {
    function courier_score_column_content( $column, $order ) {

        if ( 'courier_score' !== $column ) {
            return;
        }

        if ( $order instanceof \WC_Order ) {
            $id = $order->get_id();
        } else {
            $id = $order;
        }
        
        if ( 'courier_score' === $column ) {
            echo '<button type="button" class="button fetch-courier-score-report" data-order-id="' . esc_attr($id) . '"><span class="dashicons dashicons-image-filter"></span> ' . __('Check Score', 'order-detect') . '</button>';
            echo '<div class="courier-score" id="courier-score-preview-'.$id.'" data-order-id="'.$id.'"></div>';
        }
    }
}

if( Helper::check_license( wp_parse_args( get_option('orderdetect_license') ) ) ) {
    add_action( 'manage_shop_order_posts_custom_column', 'courier_score_column_content', 10, 2 );
    add_action( "manage_woocommerce_page_wc-orders_custom_column", 'courier_score_column_content', 10, 2 );
    add_action( "manage_woocommerce_page_wc-orders_posts_custom_column", 'courier_score_column_content', 10, 2 );
}

function normalize_customer_phone_number( $phone_number ) {
    $normalized = preg_replace('/[^\d+]/', '', $phone_number);
    if (substr($normalized, 0, 3) === '+88') {
        $normalized = substr($normalized, 3);
    } elseif (substr($normalized, 0, 2) === '88') {
        $normalized = substr($normalized, 2);
    }
    return $normalized;
}

if( Helper::check_license( wp_parse_args( get_option('orderdetect_license') ) ) ) {
    add_action( 'woocommerce_admin_order_data_after_billing_address', 'display_courier_details_in_admin', PHP_INT_MAX, 1 );
}
function display_courier_details_in_admin( $order ) {
    if ( ! $order ) {
        return null;
    }
    $billing_phone = $order->get_billing_phone();
    if ( empty( $billing_phone ) ) {
        return null;
    }

    echo '<div id="courier-details-loader" class="courier-loader"></div>';
    
    echo '<div class="courier-container" id="od-courier-container" data-order-id="' . esc_attr( $order->get_id() ) . '" data-phone-number="' . esc_attr( $billing_phone ) . '" style="display:none;">';
    echo '</div>';
}

if ( ! function_exists( 'disable_admin_notices_on_settings_page' ) ) {
    function disable_admin_notices_on_settings_page() {
        $current_screen = get_current_screen();
        if ($current_screen && $current_screen->id === 'toplevel_page_order-detect') {
            remove_all_actions('admin_notices');
            remove_all_actions('all_admin_notices');
            remove_all_actions('user_admin_notices');
            remove_all_actions('network_admin_notices');
        }
    }
}
add_action('in_admin_header', 'disable_admin_notices_on_settings_page', PHP_INT_MAX);

add_action('woocommerce_order_status_changed', 'send_sms_on_order_status_change', PHP_INT_MAX, 4);

function send_sms_on_order_status_change($order_id, $old_status, $new_status, $order) {
    $settings = wp_parse_args(get_option('orderdetect_settings', array(
		'sms_provider' => 'greenweb',
		'sms_api_key' => array(
			'greenweb' => '',
			'alpha' => '',
			'dianahost' => ''
		),
		'enable_otp' => 0,
		'checkout_otp_message' => '',
		'dianahost_sender_id' => '',
		'enable_invoice' => 0,
		'enable_packing_slip' => 0,
		'invoice_packing_slip_logo' => '',
		'business_name' => '',
		'enable_footer_text' => 0,
		'footer_text_heading' => '',
		'footer_text_details' => '',
        'delivery_partner' => '',
        'primary_color' => '#000'
	)));

    if (isset($settings["wc-".$new_status."_enable"]) && $settings["wc-".$new_status."_enable"] == 1) {
        $billing_phone = $order->get_billing_phone();
        $message_template = isset($settings["wc-".$new_status."_message"]) ? $settings["wc-".$new_status."_message"] : 'Your order status has changed.';
        $order_items = [];
        foreach ($order->get_items() as $item_id => $item) {
            $order_items[] = $item->get_name();
        }
        
        $shipping_methods = $order->get_shipping_methods();
        $shipping_method_titles = [];
        foreach ($shipping_methods as $shipping_item) {
            $shipping_method_titles[] = $shipping_item->get_method_title();
        }

        $message = str_replace(
            array(
                '%store_name%',
                '%billing_first_name%',
                '%billing_state%',
                '%billing_city%',
                '%billing_address_1%',
                '%order_id%',
                '%status%',
                '%order_date_created%',
                '%order_currency%',
                '%total_price%',
                '%payment_method%',
                '%od_items%',
                '%od_shipping%'
            ),
            array(
                get_bloginfo('name'), // %store_name%
                $order->get_billing_first_name(), // %billing_first_name%
                $order->get_billing_state(), // %billing_state%
                $order->get_billing_city(), // %billing_city%
                $order->get_billing_address_1(), // %billing_address_1%
                $order->get_id(), // %order_id%
                wc_get_order_status_name($new_status), // %status%
                $order->get_date_created()->date('Y-m-d H:i:s'), // %order_date_created%
                $order->get_currency(), // %order_currency%
                get_clean_price_with_currency($order->get_total()), // %total_price%
                $order->get_payment_method_title(), // %payment_method%
                implode(', ', $order_items), // %od_items%
                !empty($shipping_method_titles) ? implode(', ', $shipping_method_titles) : 'N/A' // %od_shipping%
            ),
            $message_template
        );
        
    
        od_send_alerts_based_on_order_status($billing_phone, $message);
    }
}
if ( ! function_exists( 'od_send_alerts_based_on_order_status' ) ) {
    function od_send_alerts_based_on_order_status($phone_number, $message) {

        global $odSmsProvider;
        $settings = wp_parse_args(get_option('orderdetect_settings', array(
            'sms_provider' => 'greenweb',
            'sms_api_key' => array(
                'greenweb' => '',
                'alpha' => '',
                'dianahost' => ''
            ),
            'enable_otp' => 0,
            'checkout_otp_message' => '',
            'dianahost_sender_id' => '',
            'enable_invoice' => 0,
            'enable_packing_slip' => 0,
            'invoice_packing_slip_logo' => '',
            'business_name' => '',
            'enable_footer_text' => 0,
            'footer_text_heading' => '',
            'footer_text_details' => '',
            'delivery_partner' => '',
            'primary_color' => '#000'
        )));
        $endpoint = $odSmsProvider[$settings['sms_provider']]; 
        $api_key = $settings["sms_api_key"][$settings['sms_provider']];
        $to = Helper::validate_and_format_phone_number( $phone_number );

        if( "greenweb" === $settings['sms_provider'] ) {
            $endpoint .= '/api.php';
            $data = [
                'to'=>"$to",
                'message'=>"$message",
                'token'=>"$api_key"
            ];
        } else if( "alpha" === $settings['sms_provider'] ) {
            $endpoint .= '/sendsms';
            $data = [
                'to'=>"$to",
                'msg'=>"$message",
                'api_key'=>"$api_key"
            ];
        } else {
            $endpoint .= '/sms/send';
            $data = [
                'recipient'=>"$to",
                'type' => 'plain',
                'sender_id' => $settings['dianahost_sender_id'],
                'message'=>"$message",
            ];
        }
        
        $ch = curl_init(); 
        curl_setopt($ch, CURLOPT_URL, $endpoint);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_ENCODING, '');

        if( "dianahost" === $settings['sms_provider'] ) {
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                'Accept: application/json',
                "Authorization: Bearer $api_key",
                "Content-Type: application/json"
            ));
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        } else {
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        }

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $smsresult = curl_exec($ch);

        if ($smsresult === false) {
            error_log('cURL Error: ' . curl_error($ch));
        } else {
            error_log('cURL Response: ' . $smsresult);
        }
        curl_close($ch);

        Helper::update_balance();
        Helper::send_sms_balance_notification();

    }
}

if ( ! function_exists( 'get_clean_price_with_currency' ) ) {
    function get_clean_price_with_currency($price) {
        return html_entity_decode(strip_tags(wc_price($price)));
    }
}

if ( ! function_exists( 'remove_admin_notices_on_multi_order_tracker_page' ) ) {
    function remove_admin_notices_on_multi_order_tracker_page() {
        $current_screen = get_current_screen();
        if ($current_screen && $current_screen->id === 'order-detect_page_sms-log') {
            remove_all_actions('admin_notices');
            remove_all_actions('all_admin_notices');
            remove_all_actions('user_admin_notices');
            remove_all_actions('network_admin_notices');
        }
    }
    add_action( 'in_admin_header', 'remove_admin_notices_on_multi_order_tracker_page', PHP_INT_MAX );
}

if ( ! function_exists( 'add_od_invoice_packing_slip_column_header' ) ) {
    function add_od_invoice_packing_slip_column_header( $columns ) {
        $new_columns = array();

        $settings = wp_parse_args(get_option('orderdetect_settings', array(
            'sms_provider' => 'greenweb',
            'sms_api_key' => array(
                'greenweb' => '',
                'alpha' => '',
                'dianahost' => ''
            ),
            'enable_otp' => 0,
            'checkout_otp_message' => '',
            'dianahost_sender_id' => '',
            'enable_invoice' => 0,
            'enable_packing_slip' => 0,
            'invoice_packing_slip_logo' => '',
            'business_name' => '',
            'enable_footer_text' => 0,
            'footer_text_heading' => '',
            'footer_text_details' => '',
            'delivery_partner' => '',
            'primary_color' => '#000'
        )));

        foreach ( $columns as $column_name => $column_info ) {
            $new_columns[ $column_name ] = $column_info;
            if ( 'order_track' === $column_name && 1 == $settings['enable_invoice'] ) {
                $new_columns['invoice_packing_slip'] = __( 'Invoice', 'order-detect' );
            }
        }
        return $new_columns;
    }
}

if( Helper::check_license( wp_parse_args( get_option('orderdetect_license') ) ) ) {
    add_filter( 'manage_edit-shop_order_columns', 'add_od_invoice_packing_slip_column_header', 20 );
    add_filter( "manage_woocommerce_page_wc-orders_columns", 'add_od_invoice_packing_slip_column_header', 20 );
    add_filter( "manage_edit-woocommerce_page_wc-orders_columns", 'add_od_invoice_packing_slip_column_header', 20 );
}

if ( ! function_exists( 'od_invoice_packing_slip_button' ) ) {
    function od_invoice_packing_slip_button( $column, $order ) {

        if ( 'invoice_packing_slip' !== $column ) {
            return;
        }

        if ( $order instanceof \WC_Order ) {
            $id = $order->get_id();
        } else {
            $id = $order;
        }

        $settings = wp_parse_args(get_option('orderdetect_settings', array(
            'sms_provider' => 'greenweb',
            'sms_api_key' => array(
                'greenweb' => '',
                'alpha' => '',
                'dianahost' => ''
            ),
            'enable_otp' => 0,
            'checkout_otp_message' => '',
            'dianahost_sender_id' => '',
            'enable_invoice' => 0,
            'enable_packing_slip' => 0,
            'invoice_packing_slip_logo' => '',
            'business_name' => '',
            'enable_footer_text' => 0,
            'footer_text_heading' => '',
            'footer_text_details' => '',
            'delivery_partner' => '',
            'primary_color' => '#000'
        )));
        
        if ( 'invoice_packing_slip' === $column ) {
            $nonce = wp_create_nonce('order-detect');

            if( 1 == $settings['enable_invoice'] ) {

                $od_print_invoice = add_query_arg([
                'print_od_packinglist' => 'true',
                'post' => $id,
                'type' => 'od_print_invoice',
                '_wpnonce' => $nonce
                ], admin_url());

                // $od_download_invoice = add_query_arg([
                // 'print_od_packinglist' => 'true',
                // 'post' => $id,
                // 'type' => 'od_download_invoice',
                // '_wpnonce' => $nonce
                // ], admin_url());
                $tooltip_text = "Print Invoice";
                $print_history = [];
                $printed = "";
                $print_history = get_post_meta( $id, 'print_history', true);
                if( ! empty($print_history) ){
                    $tooltip_text = "Already Printed";
                    $printed = "color: #f3793d !important; opacity:0.7;";
                }
                echo '<a href="'.esc_url($od_print_invoice).'" class="od_pklist_admin_print_document_btn od-tooltip"><span class="od-tooltiptext">'.$tooltip_text.'</span><span class="dashicons dashicons-printer" style="'.$printed.'"></span></a>';
                // echo '<a href="'.esc_url($od_download_invoice).'" class="od_pklist_admin_print_document_btn"><span class="dashicons dashicons-download"></span> Download</a>';
            }
            // if( 1 === $settings['enable_packing_slip'] ) {

            //     $print_packingslip = add_query_arg([
            //         'print_od_packinglist' => 'true',
            //         'post' => $id,
            //         'type' => 'print_packingslip',
            //         '_wpnonce' => $nonce
            //         ], admin_url());

            //     echo '<a href="'.esc_url($print_packingslip).'" class="button od_pklist_admin_print_document_btn"><span class="dashicons dashicons-media-text"></span> Packing Slip</a>';
            // }
        }
    }
}

if( Helper::check_license( wp_parse_args( get_option('orderdetect_license') ) ) ) {
    add_action( 'manage_shop_order_posts_custom_column', 'od_invoice_packing_slip_button', 10, 2 );
    add_action( "manage_woocommerce_page_wc-orders_custom_column", 'od_invoice_packing_slip_button', 10, 2 );
    add_action( "manage_woocommerce_page_wc-orders_posts_custom_column", 'od_invoice_packing_slip_button', 10, 2 );
}

add_action('wp_footer', 'add_otp_enable_forcefully');
function add_otp_enable_forcefully(){
    $settings = wp_parse_args(get_option('orderdetect_settings', array(
        'sms_provider' => 'greenweb',
        'sms_api_key' => array(
            'greenweb' => '',
            'alpha' => '',
            'dianahost' => ''
        ),
        'enable_otp' => 0,
        'checkout_otp_message' => '',
        'dianahost_sender_id' => '',
        'enable_invoice' => 0,
        'enable_packing_slip' => 0,
        'invoice_packing_slip_logo' => '',
        'business_name' => '',
        'enable_footer_text' => 0,
        'footer_text_heading' => '',
        'footer_text_details' => '',
        'delivery_partner' => '',
        'primary_color' => '#000'
    )));
    if( isset($settings['enable_otp']) && 1 == $settings['enable_otp'] ) {
    ?>
    <script>
        jQuery(document).ready(function($) {
            function updateButtonClass() {
                var $button = $('button[name="woocommerce_checkout_place_order"]');
                if ($button.length) {
                    if (!$button.hasClass('button') || !$button.hasClass('alt') || !$button.hasClass('show-otp-popup')) {
                        $button.addClass('button alt show-otp-popup');
                    }
                }
            }

            $(document).ready(updateButtonClass);
            $(document).ajaxComplete(updateButtonClass);
            $(document.body).on('updated_checkout payment_method_selected update_checkout', updateButtonClass);
            setInterval(updateButtonClass, 500);
        });
    </script>
    <?php
    }
}