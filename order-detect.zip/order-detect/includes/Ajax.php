<?php
namespace OrderDetect;

use OrderDetect\Helper;


class Ajax {


    private $settings;

    function __construct() {
        $this->settings = wp_parse_args(get_option('orderdetect_settings', array(
            'sms_provider' => 'greenweb',
            'sms_api_key' => array(
                'greenweb' => '',
                'alpha' => '',
                'dianahost' => ''
            ),
            'enable_otp' => 0,
            'checkout_otp_message' => '',
            'dianahost_sender_id' => '',
            'enable_invoice' => 0,
            'enable_packing_slip' => 0,
            'invoice_packing_slip_logo' => '',
            'business_name' => '',
            'enable_footer_text' => 0,
            'footer_text_heading' => '',
            'footer_text_details' => '',
            'delivery_partner' => '',
            'primary_color' => '#000'
        )));

        add_action('wp_ajax_license_activate', array($this, 'license_activate'));
        add_action('wp_ajax_nopriv_license_activate', array($this, 'license_activate'));

        add_action('wp_ajax_license_deactivate', array($this, 'license_deactivate'));
        add_action('wp_ajax_nopriv_license_deactivate', array($this, 'license_deactivate'));

        add_action('wp_ajax_send_otp', array($this, 'send_otp'));
        add_action('wp_ajax_nopriv_send_otp', array($this, 'send_otp'));

        add_action('wp_ajax_verify_otp', array($this, 'verify_otp'));
        add_action('wp_ajax_nopriv_verify_otp', array($this, 'verify_otp'));

        add_action('wp_ajax_check_phone_is_verified', array($this, 'check_phone_is_verified'));
        add_action('wp_ajax_nopriv_check_phone_is_verified', array($this, 'check_phone_is_verified'));

        add_action('wp_ajax_get_customer_orders', array($this, 'get_customer_orders'));
        add_action('wp_ajax_nopriv_get_customer_orders', array($this, 'get_customer_orders'));

        add_action('wp_ajax_load_order_by_phone', array($this, 'load_order_by_phone'));
		add_action('wp_ajax_nopriv_load_order_by_phone', array($this, 'load_order_by_phone'));

        add_action('wp_ajax_load_courier_scores_by_phone', array($this, 'load_courier_scores_by_phone') );
		add_action('wp_ajax_nopriv_load_courier_scores_by_phone', array($this, 'load_courier_scores_by_phone') );

        add_action('wp_ajax_load_courier_scores_by_phone_sms_list', array($this, 'load_courier_scores_by_phone_sms_list') );
		add_action('wp_ajax_nopriv_load_courier_scores_by_phone_sms_list', array($this, 'load_courier_scores_by_phone_sms_list') );

        add_action('wp_ajax_load_courier_score_order_details_page', array($this, 'load_courier_score_order_details_page') );
        add_action('wp_ajax_nopriv_load_courier_score_order_details_page', array($this, 'load_courier_score_order_details_page') );

        add_action('wp_ajax_save_sms_provider_settings', array($this, 'save_sms_provider_settings') );
        add_action('wp_ajax_nopriv_save_sms_provider_settings', array($this, 'save_sms_provider_settings') );

        add_action('wp_ajax_save_otp_settings', array($this, 'save_otp_settings') );
        add_action('wp_ajax_nopriv_save_otp_settings', array($this, 'save_otp_settings') );

        add_action('wp_ajax_save_order_alerts', array($this, 'save_order_alerts') );
        add_action('wp_ajax_nopriv_save_order_alerts', array($this, 'save_order_alerts') );

        add_action('wp_ajax_update_phone_number_status', array($this, 'update_phone_number_status') );
        add_action('wp_ajax_nopriv_update_phone_number_status', array($this, 'update_phone_number_status') );

        add_action('wp_ajax_save_invoice_packing_slip_settings', array($this, 'save_invoice_packing_slip_settings') );
        add_action('wp_ajax_nopriv_save_invoice_packing_slip_settings', array($this, 'save_invoice_packing_slip_settings') );

    }

    public function license_activate() {
        check_ajax_referer('order-detect-admin-nonce', 'security');

        $license_key = sanitize_text_field($_POST['license_key']);
        if (isset($license_key)) {
            $license_key = sanitize_text_field($_POST['license_key']);
            $api_params = array(
                'edd_action' => 'activate_license',
                'license'    => $license_key,
                'item_name'  => urlencode(ORDERDETECT_SL_ITEM_NAME),
                'url'        => home_url()
            );

            $response = wp_remote_post(esc_url(ORDERDETECT_STORE_URL), array( 'timeout' => 9999, 'sslverify' => false, 'body' => $api_params, 'headers' => array(
                'User-Agent' => 'Order Detect/1.0.0; ' . home_url('/')
            ) ) );

            if (is_wp_error($response) || 200 !== wp_remote_retrieve_response_code( $response )) {
                wp_send_json(array('message' => $response->get_error_message(), 'class' => 'order-detect-license-status-error'), 500);
            }

            $license_data = json_decode(wp_remote_retrieve_body($response));

            if ($license_data->success) {
                $settings = [];
                $settings['key'] = Helper::encrypt_data($license_key, ORDERDETECT_ENCRYPTION_KEY, ORDERDETECT_IV);
                $settings['expires'] = Helper::encrypt_data($license_data->expires, ORDERDETECT_ENCRYPTION_KEY, ORDERDETECT_IV);
                update_option('orderdetect_license', $settings);
                wp_send_json(array('message' => 'License activated successfully.', 'class' => 'order-detect-license-status-success'), 200);
            } else {
                wp_send_json(array('message' => 'License activation failed: '.$license_data->error, 'class' => 'order-detect-license-status-error'), 400);
            }
        } else {
            wp_send_json(array('message' => 'License key invalid!', 'class' => 'order-detect-license-status-error'), 400);
        }

        wp_die();
    }

    public function license_deactivate() {
        check_ajax_referer('order-detect-admin-nonce', 'security');
    
        $orderdetect_license = get_option('orderdetect_license');
        $license_key = isset($orderdetect_license['key']) ? $orderdetect_license['key'] : '';
        
        if ($license_key) {
            $api_params = array(
                'edd_action' => 'deactivate_license',
                'license'   => Helper::decrypt_data($license_key, ORDERDETECT_ENCRYPTION_KEY, ORDERDETECT_IV),
                'item_name' => urlencode(ORDERDETECT_SL_ITEM_NAME),
                'url'       => home_url()
            );
    
            $response = wp_remote_post(esc_url(ORDERDETECT_STORE_URL), array( 'timeout' => 9999, 'sslverify' => false, 'body' => $api_params, 'headers' => array(
                'User-Agent' => 'Order Detect/1.0.0; ' . home_url('/')
            ) ) );
    
            if (is_wp_error($response) || 200 !== wp_remote_retrieve_response_code( $response )) {
                wp_send_json(array('message' => $response->get_error_message(), 'class' => 'order-detect-license-status-error'), 500);
            }
    
            $license_data = json_decode(wp_remote_retrieve_body($response));
            if ($license_data && $license_data->success) {
                delete_option('orderdetect_license');
                wp_send_json(array('message' => 'License deactivated successfully.', 'class' => 'order-detect-license-status-success'), 200);
            } elseif ($license_data && isset($license_data->license) && $license_data->license == 'failed') {
                delete_option('orderdetect_license');
                wp_send_json(array('message' => 'License was already inactive. Local data cleaned.', 'class' => 'order-detect-license-status-warning'), 200);
            } else {
                $error_message = isset($license_data->error) ? $license_data->error : 'Unknown error';
                wp_send_json(array('message' => 'License deactivation failed: ' . $error_message, 'class' => 'order-detect-license-status-error'), 400);
            }
        } else {
            wp_send_json(array('message' => 'License key not found.', 'class' => 'order-detect-license-status-error'), 400);
        }
    
        wp_die();
    }        

    public function send_otp() {
        check_ajax_referer('order-detect-nonce', 'security');

        $phone_number = isset($_POST['phone_number']) ? sanitize_text_field($_POST['phone_number']) : '';
        $response = array();

        if (!Helper::is_valid_Bangladeshi_phone_number($phone_number)) {
            $response['success'] = false;
            $response['message'] = __('Invalid phone number format. Please enter a valid Bangladeshi phone number.', 'order-detect');
            wp_send_json($response, 400);
        }

        $otp = Helper::generate_otp($phone_number);

        if (!$otp) {
            $response['success'] = false;
            $response['message'] = __('Failed to generate OTP. Please try again later.', 'order-detect');
            wp_send_json($response, 500);
        }

        global $odSmsProvider;
        $enable = array_key_exists('enable_otp', $this->settings) ? $this->settings['enable_otp'] : '0';
        $endpoint = $odSmsProvider[$this->settings['sms_provider']]; 
        $api_key = $this->settings["sms_api_key"][$this->settings['sms_provider']];
        $checkout_otp_message = array_key_exists('checkout_otp_message', $this->settings) ? $this->settings['checkout_otp_message'] : '';

        if ( ! empty($enable) && $enable == 1 &&  ! empty($endpoint) &&  ! empty($api_key) &&  ! empty($checkout_otp_message) ) {
            $domain = $_SERVER['HTTP_HOST'];
            $message = str_replace(array('(', ')'), '', $checkout_otp_message);
            $message = str_replace('%otp_code%', $otp, $message);
            $message = str_replace('@domain', $domain, $message);

            $to = Helper::validate_and_format_phone_number( $phone_number );

            if("greenweb" === $this->settings['sms_provider'] ) {
                $endpoint .= '/api.php';
                $data = [
                    'to'=>"$to",
                    'message'=>"$message",
                    'token'=>"$api_key"
                ];
            } else if( "alpha" === $this->settings['sms_provider'] ) {
                $endpoint .= '/sendsms';
                $data = [
                    'to'=>"$to",
                    'msg'=>"$message",
                    'api_key'=>"$api_key"
                ];
            } else {
                $endpoint .= '/sms/send';
                $data = [
                    'recipient'=>"$to",
                    'type' => 'plain',
                    'sender_id' => $this->settings['dianahost_sender_id'],
                    'message'=>"$message",
                ];
            }
            
            $ch = curl_init(); 
            curl_setopt($ch, CURLOPT_URL, $endpoint);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
            curl_setopt($ch, CURLOPT_ENCODING, '');
            if( "dianahost" === $this->settings['sms_provider'] ) {
                curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    'Accept: application/json',
                    "Authorization: Bearer $api_key",
                    "Content-Type: application/json"
                ));
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
            } else {
                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
            }
    
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $smsresult = curl_exec($ch);
            curl_close($ch);

            Helper::update_balance();
            Helper::send_sms_balance_notification();
        }

        $response['success'] = true;
        $response['message'] = sprintf(__('OTP has been sent to: %s', 'order-detect'), $phone_number);
        wp_send_json($response, 200);
        wp_die();
    }

    public function verify_otp() {
        check_ajax_referer('order-detect-nonce', 'security');

        $phone_number = isset($_POST['phone_number']) ? $_POST['phone_number'] : '';
        $otp = isset($_POST['otp']) ? sanitize_text_field($_POST['otp']) : '';

        $response = array();

        $otp_verified = Helper::verify_otp($phone_number, $otp);

        if ($otp_verified) {
            Helper::set_phone_number_verified($phone_number);
            $response['success'] = true;
            $response['message'] = 'OTP verification successful!';
        } else {
            $response['success'] = false;
            $response['message'] = 'OTP verification failed. Invalid OTP.';
        }

        wp_send_json($response, 200);
        wp_die();
    }

    public function check_phone_is_verified() {

        check_ajax_referer('order-detect-nonce', 'security');

        $phone_number = isset($_POST['phone_number']) ? $_POST['phone_number'] : '';
        $is_verified = Helper::is_phone_number_verified($phone_number);
        if ($is_verified) {
            $response['success'] = true;
            $response['message'] = 'This phone number has already been verified.';
        } else {
            $response['success'] = false;
            $response['message'] = 'This phone number is not verified.';
        }

        wp_send_json($response, 200);
    }

    public function get_customer_orders() {
        $order_id = intval($_POST['order_id']);
        $order = wc_get_order($order_id);
        
        if (!$order) {
            wp_send_json_error(array('message' => 'Invalid order ID'));
            return;
        }

        $customer_phone = $order->get_billing_phone();
        
        if (empty($customer_phone)) {
            wp_send_json_error(array('message' => 'No phone number found for this order'));
            return;
        }

        $args = array(
            'post_type' => 'shop_order',
            'post_status' => array_keys(wc_get_order_statuses()), // Include all order statuses
            'meta_query' => array(
                array(
                    'key' => '_billing_phone',
                    'value' => $customer_phone,
                    'compare' => '='
                ),
            ),
            'posts_per_page' => -1,
            'post__not_in' => array($order_id),
        );

        $orders = get_posts($args);
        
        if (empty($orders)) {
            wp_send_json_error(array('message' => 'No orders found for this customer phone number'));
            return;
        }

        $orders_data = array();
        
        foreach ($orders as $customer_order) {
            $order_id = $customer_order->ID;
            $order_date = $customer_order->post_date;
            $order_status = wc_get_order_status_name($customer_order->post_status);
            $order_total = get_post_meta($order_id, '_order_total', true);

            $orders_data[] = array(
                'id' => $order_id,
                'date' => $order_date,
                'status' => $order_status,
                'total' => wc_price($order_total),
                'edit_link' => admin_url('post.php?post=' . $order_id . '&action=edit')
            );
        }

        wp_send_json_success(array('orders' => $orders_data));

    }

    public function load_order_by_phone(){
        check_ajax_referer('order-detect-admin-nonce', 'security');
        
        // Fetch all available statuses
        $available_statuses = wc_get_order_statuses();
     
        if ( isset( $_POST['order_id'] ) ) {
            $order_id = intval( $_POST['order_id'] );
            $order = wc_get_order( $order_id );
            $first_name = $order->get_billing_first_name(); 
            $last_name  = $order->get_billing_last_name();
            $full_name = $first_name .' '. $last_name;
            $email     = $order->get_billing_email(); 
            $phone     = $order->get_billing_phone();
            $orders_list = get_orders_by_phone_number( $phone );

            if ( count($orders_list) > 1 ) {
        
                // Initialize counts dynamically for all statuses
                $order_counts = ['all' => 0]; // Always include 'all'
                foreach ( $available_statuses as $status_key => $status_label ) {
                    $order_counts[ str_replace( 'wc-', '', $status_key ) ] = 0; // Strip 'wc-' prefix
                }

                foreach ( $orders_list as $order ) {
                    $status = $order->get_status();
                    if ( isset( $order_counts[$status] ) ) {
                        $order_counts[$status]++;
                    }
                    $order_counts['all']++;
                }

                $statuses = array_unique( wp_list_pluck( $orders_list, 'status' ) );
                $status_links = ['all' => $order_counts['all']]; // Include 'all' link
                foreach ( $order_counts as $status => $count ) {
                    if ( $status !== 'all' && $count > 0 ) {
                        $status_links[$status] = $count;
                    }
                }

                ob_start();
                ?>
                <div class="order-detect-modal-dialog" id="order-detect-modal-dialog-<?php echo intval( $order_id ); ?>">
                    <div class="order-detect-modal">
                        <div class="order-detect-modal-content">
                            <section class="order-detect-modal-main" role="main">
                                <header class="order-detect-modal-header">
                                    <h1><?php esc_html_e( 'Multi-Order Tracking', 'order-detect' ); ?></h1>
                                    <button class="order-detect-modal-close order-detect-modal-close-link dashicons dashicons-no-alt">
                                        <span class="screen-reader-text"><?php esc_html_e( 'Close modal panel', 'order-detect' ); ?></span>
                                    </button>
                                </header>
                                <div class="wc-order-preview-addresses order-detect-preview-parent">
                                    <div class="wc-order-preview-address">
                                        <h2><?php esc_html_e( 'Customer details', 'order-detect' ); ?></h2>
                                        <strong><?php esc_html_e( 'Name: ', 'order-detect' ); ?></strong> <?php esc_attr_e( $full_name ); ?> <br>
                                        <strong><?php esc_html_e( 'Email: ', 'order-detect' ); ?></strong> <a href="mailto:<?php esc_attr_e( $email ); ?>"><?php esc_attr_e( $email ); ?></a> <br>
                                        <strong><?php esc_html_e( 'Phone: ', 'order-detect' ); ?></strong> <a href="<?php esc_attr_e( $phone ); ?>"><?php esc_attr_e( $phone ); ?></a> <br>
                                    </div>
                                    <div class="order-status-area">
                                        <ul class="subsubsub">
                                            <?php foreach ( $status_links as $status => $count ) : ?>
                                                <?php if ( $count > 0 ) : ?>
                                                    <li class="<?php echo esc_attr( 'wc-' . $status ); ?>">
                                                        <a href="#" class="<?php echo $status === 'all' ? 'current' : ''; ?>" data-status="<?php echo esc_attr( $status ); ?>">
                                                            <?php echo esc_html( ucfirst( str_replace( '-', ' ', $status ) ) ); ?>
                                                            <span class="count">(<?php echo esc_html( $count ); ?>)</span>
                                                        </a>
                                                        <?php if ( $status !== array_key_last( $status_links ) ) : ?>
                                                            |
                                                        <?php endif; ?>
                                                    </li>
                                                <?php endif; ?>
                                            <?php endforeach; ?>
                                        </ul>
                                    </div>    
                                    <div class="order-detect-header">
                                        <div class="od-header-item"><?php esc_html_e( 'Order', 'order-detect' ); ?></div>
                                        <div class="od-header-item"><?php esc_html_e( 'Date', 'order-detect' ); ?></div>
                                        <div class="od-header-item"><?php esc_html_e( 'Status', 'order-detect' ); ?></div>
                                        <div class="od-header-item"><?php esc_html_e( 'Total', 'order-detect' ); ?></div>
                                        <div class="od-header-item"><?php esc_html_e( 'Action', 'order-detect' ); ?></div>
                                    </div>
                                    <div class="wc-order-preview-table-wrapper" id="order-detect-preview-<?php echo $order_id; ?>">
                                        <?php if ( count( $orders_list ) ): ?>
                                            <?php foreach ( $orders_list as $order ) : ?>
                                                <div class="order-detect-row order-status-<?php echo esc_attr( $order->get_status() ); ?>">
                                                    <div class="od-customer-name" style="width: 100%;">
                                                        <?php
                                                            $buyer = '';
                                                            if ( $order->get_billing_first_name() || $order->get_billing_last_name() ) {
                                                                $buyer = trim( sprintf( _x( '%1$s %2$s', 'full name', 'woocommerce' ), $order->get_billing_first_name(), $order->get_billing_last_name() ) );
                                                            } elseif ( $order->get_billing_company() ) {
                                                                $buyer = trim( $order->get_billing_company() );
                                                            } elseif ( $order->get_customer_id() ) {
                                                                $user  = get_user_by( 'id', $order->get_customer_id() );
                                                                $buyer = ucwords( $user->display_name );
                                                            }
                                                            echo '<strong>#' . esc_attr( $order->get_order_number() ) . ' ' . esc_html( $buyer ) . '</strong>'; 
                                                        ?>
                                                    </div>
                                                    <div class="od-purchase-date" style="width: 100%;"><?php echo date_i18n( 'M j, Y', strtotime( $order->get_date_created() ) ); ?></div>
                                                    <div class="od-status" style="width: 100%;"><?php echo wc_get_order_status_name( $order->get_status() ); ?></div>
                                                    <div class="od-purchase-price" style="width: 100%;"><?php echo wp_strip_all_tags( wc_price( $order->get_total() ) ); ?></div>
                                                    <div class="od-action" style="width: 100%;">
                                                        <?php 
                                                            $order_link = admin_url( 'post.php?post=' . $order->get_id() . '&action=edit' );
                                                            echo '<a href="' . esc_url( $order_link ) . '" class="button button-primary button-large od-view-order" target="_blank">' . __( "View", "order-detect" ) . '</a>';
                                                        ?>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <div class="order-detect-row">
                                                <div class="od-no-orders"><?php esc_html_e( 'Other orders not found!', 'order-detect' ); ?></div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </section>
                        </div>
                    </div>
                    <div class="order-detect-modal-backdrop"></div>
                </div>
                <script>
                    jQuery(document).ready(function($) {
                        // Cache the relevant elements
                        const modalDialog = $('#order-detect-modal-dialog-<?php echo intval( $order_id ); ?>');
                        const statusLinks = modalDialog.find('.order-status-area a[data-status]');
                        const rowsContainer = modalDialog.find('.wc-order-preview-table-wrapper');
                        const rows = rowsContainer.find('.order-detect-row');

                        // Event handler for status link clicks
                        statusLinks.on('click', function(e) {
                            e.preventDefault();

                            const selectedStatus = $(this).data('status');
                            if (rows.length) {
                                rows.each(function() {
                                    const row = $(this);
                                    // Extract the full order-status class (including hyphens)
                                    const rowClassMatch = row.attr('class').match(/order-status-[\w-]+/);
                                    const rowStatusClass = rowClassMatch ? rowClassMatch[0] : '';                                    
                                
                                    if (selectedStatus === 'all' || rowStatusClass === `order-status-${selectedStatus}`) {
                                        row.show();
                                    } else {
                                        row.hide();
                                    }
                                });

                                // Update the 'current' class for the active status link
                                statusLinks.removeClass('current');
                                $(this).addClass('current');
                            }
                        });
                    });
                </script>
                <?php
                $output = ob_get_clean();
                wp_send_json_success( array("html" => $output) );

            }
        }
        
        wp_send_json_error(array('html' => ''));
        wp_die();
    }

    public function load_courier_scores_by_phone() {
        check_ajax_referer( 'order-detect-admin-nonce', 'security' );
    
        $output = '';
        $score = array(
            'ALL' => 0,
            'DELIVERED' => 0,
            'CANCELLED' => 0,
        );
    
        if ( isset( $_POST['order_id'] ) ) {
            $order_id = intval( sanitize_text_field( $_POST['order_id'] ) );
            $order = wc_get_order( $order_id );
    
            if ( $order ) {
                $phone_number = $order->get_billing_phone();
                $url = 'https://dash.orderdetect.com/wp-json/courier_score/v1/delivery-tracker?phone=' . urlencode( $phone_number );
                $response = wp_remote_get( esc_url( $url ), array( 'timeout' => 90 ) );
    
                if ( is_wp_error( $response ) ) {
                    error_log( 'Error fetching: ' . $response->get_error_message() );
                    wp_send_json_error( array( 'message' => 'Failed to fetch courier scores.' ), 500 );
                    wp_die();
                }
    
                $body = wp_remote_retrieve_body( $response );
                $data = json_decode( $body, true );
    
                if ( !is_array( $data ) || empty( $data ) ) {
                    wp_send_json_error( array( 'message' => 'Invalid response from API.' ), 500 );
                    wp_die();
                }
    
                foreach ( $data as $courier => $report ) {
                    if ( is_array( $report ) ) {
                        $score['ALL'] += isset( $report['total'] ) ? intval( $report['total'] ) : 0;
                        $score['DELIVERED'] += isset( $report['delivered'] ) ? intval( $report['delivered'] ) : 0;
                        $score['CANCELLED'] += isset( $report['cancelled'] ) ? intval( $report['cancelled'] ) : 0;
                    }
                }
    
                $percent = ( $score['ALL'] > 0 ) ? round( ( $score['DELIVERED'] / $score['ALL'] ) * 100 ) : 100;

                $output .= '<div class="courier-score-light-grey">';
                $output .= '<div class="courier-score-container courier-score-green" style="height:10px; width:' . $percent . '%"></div>';
                $output .= '</div>';
                $output .= '<div class="courier-score-statistics">';
                $output .= '<span class="all-parcels" style="color: #444;">ALL: ' . $score['ALL'] . '</span> | ';
                $output .= '<span class="delivered-parcels" style="color: #25b003;">DELIVERED: ' . $score['DELIVERED'] . '</span> | ';
                $output .= '<span class="cancelled-parcels" style="color: #fa3b1d;">CANCELLED: ' . $score['CANCELLED'] . '</span>';
                $output .= '</div>';

                wp_send_json_success( $output );
            } else {
                wp_send_json_error( array( 'message' => 'Invalid order ID.' ), 400 );
            }
        } else {
            wp_send_json_error( array( 'message' => 'No order ID provided.' ), 400 );
        }
    }    
    public function load_courier_scores_by_phone_sms_list() {
        check_ajax_referer( 'order-detect-admin-nonce', 'security' );
    
        $output = '';
        $score = array(
            'ALL' => 0,
            'DELIVERED' => 0,
            'CANCELLED' => 0,
        );
    
        if ( isset( $_POST['phone_number'] ) ) {
            $phone_number =  sanitize_text_field( $_POST['phone_number'] ) ;
            
    
            if ( $phone_number ) {
               
                $url = 'https://dash.orderdetect.com/wp-json/courier_score/v1/delivery-tracker?phone=' . urlencode( $phone_number );
                $response = wp_remote_get( esc_url( $url ), array( 'timeout' => 90 ) );
    
                if ( is_wp_error( $response ) ) {
                    error_log( 'Error fetching: ' . $response->get_error_message() );
                    wp_send_json_error( array( 'message' => 'Failed to fetch courier scores.' ), 500 );
                    wp_die();
                }
    
                $body = wp_remote_retrieve_body( $response );
                $data = json_decode( $body, true );
    
                if ( !is_array( $data ) || empty( $data ) ) {
                    wp_send_json_error( array( 'message' => 'Invalid response from API.' ), 500 );
                    wp_die();
                }
    
                foreach ( $data as $courier => $report ) {
                    if ( is_array( $report ) ) {
                        $score['ALL'] += isset( $report['total'] ) ? intval( $report['total'] ) : 0;
                        $score['DELIVERED'] += isset( $report['delivered'] ) ? intval( $report['delivered'] ) : 0;
                        $score['CANCELLED'] += isset( $report['cancelled'] ) ? intval( $report['cancelled'] ) : 0;
                    }
                }
    
                $percent = ( $score['ALL'] > 0 ) ? round( ( $score['DELIVERED'] / $score['ALL'] ) * 100 ) : 100;

                $output .= '<div class="courier-score-light-grey">';
                $output .= '<div class="courier-score-container courier-score-green" style="height:10px; width:' . $percent . '%"></div>';
                $output .= '</div>';
                $output .= '<div class="courier-score-statistics">';
                $output .= '<span class="all-parcels" style="color: #444;">ALL: ' . $score['ALL'] . '</span> | ';
                $output .= '<span class="delivered-parcels" style="color: #25b003;">DELIVERED: ' . $score['DELIVERED'] . '</span> | ';
                $output .= '<span class="cancelled-parcels" style="color: #fa3b1d;">CANCELLED: ' . $score['CANCELLED'] . '</span>';
                $output .= '</div>';

                wp_send_json_success( $output );
            } else {
                wp_send_json_error( array( 'message' => 'Invalid Phone Number.' ), 400 );
            }
        } else {
            wp_send_json_error( array( 'message' => 'No Phone Number provided.' ), 400 );
        }
    }    

    public function load_courier_score_order_details_page() {
        check_ajax_referer( 'order-detect-admin-nonce', 'security' );

        if ( isset( $_POST['phone_number'] ) && intval( $_POST['phone_number'] ) ) {

            $normalized_phone = normalize_customer_phone_number( $_POST['phone_number'] );   
            $url = 'https://dash.orderdetect.com/wp-json/courier_score/v1/delivery-tracker?phone=' . urlencode( $normalized_phone );

            $max_retries = 3;
            $retry_delay = 2;
            $attempt = 0;
            $response = null;
    
            do {
                $response = wp_remote_get(esc_url($url), array(
                    'timeout' => 90,
                ));
    
                if (is_wp_error($response)) {
                    error_log("API request failed: attempt ".$attempt."" . $response->get_error_message());
                    sleep($retry_delay);
                    $attempt++;
                    continue;
                }
    
                $body = wp_remote_retrieve_body($response);
                $courier_details = json_decode($body, true);
                if (empty($courier_details['pathao']) || 
                    (isset($courier_details['pathao']['total']) && $courier_details['pathao']['total'] == 0)) {
                    error_log("Pathao data is ==> ".print_r($courier_details['pathao'], true)." Retrying...".$attempt."");
                    sleep($retry_delay);
                    $attempt++;
                } else {
                    break;
                }
            } while ($attempt < $max_retries);

            $body = wp_remote_retrieve_body($response);
            $courier_details = json_decode($body, true);
            wp_send_json_success( $courier_details );
        }
        wp_send_json_success( array( 'html' => '<p>No delivery details found for this order.</p>' ) );
    }

    public function save_sms_provider_settings() {
        check_ajax_referer('order-detect-admin-nonce', 'security');
    
        $sms_provider = sanitize_text_field($_POST['sms_provider']);
        $sms_api_key = sanitize_text_field($_POST['sms_api_key']);
    
        $settings = wp_parse_args(get_option('orderdetect_settings', array(
            'sms_provider' => 'greenweb',
            'sms_api_key' => array(
                'greenweb' => '',
                'alpha' => '',
                'dianahost' => ''
            ),
            'enable_otp' => 0,
            'checkout_otp_message' => '',
            'dianahost_sender_id' => '',
            'enable_invoice' => 0,
            'enable_packing_slip' => 0,
            'invoice_packing_slip_logo' => '',
            'business_name' => '',
            'enable_footer_text' => 0,
            'footer_text_heading' => '',
            'footer_text_details' => '',
            'delivery_partner' => '',
            'primary_color' => '#000'
            
        )));
    
        $settings['sms_provider'] = $sms_provider;
        $settings['sms_api_key'][ $sms_provider ] = $sms_api_key;

        if( isset($_POST['dianahost_sender_id']) ){
            $settings['dianahost_sender_id'] = sanitize_text_field($_POST['dianahost_sender_id']);
        }

        update_option('orderdetect_settings', $settings);

        if (
            !empty($_POST['sms_provider']) &&
            !empty($_POST['sms_api_key'])
        ) {
            Helper::update_balance();
            $balance = get_option( 'orderdetect_sms_balance' , [
                'greenweb' => 0.00,
                'alpha' => 0.00,
                'dianahost' => 0.00,
            ]);
        } 
        wp_send_json_success(array('message' => 'SMS Provider Saved Successfully!', 'balance' => $balance[ $sms_provider ]) );

    }

    public function save_otp_settings() {
        check_ajax_referer('order-detect-admin-nonce', 'security');
    
        $enable_otp = isset($_POST['enable_otp']) ? intval($_POST['enable_otp']) : 0;
        $checkout_otp_message = sanitize_textarea_field($_POST['checkout_otp_message']);
    
        $settings = wp_parse_args(get_option('orderdetect_settings', array(
            'sms_provider' => 'greenweb',
            'sms_api_key' => array(
                'greenweb' => '',
                'alpha' => '',
                'dianahost' => ''
            ),
            'enable_otp' => 0,
            'checkout_otp_message' => '',
            'dianahost_sender_id' => '',
            'enable_invoice' => 0,
            'enable_packing_slip' => 0,
            'invoice_packing_slip_logo' => '',
            'business_name' => '',
            'enable_footer_text' => 0,
            'footer_text_heading' => '',
            'footer_text_details' => '',
            'delivery_partner' => '',
            'primary_color' => '#000'
        )));
    
        if ($enable_otp) {
            $settings['enable_otp'] = $enable_otp;
        } else {
            unset($settings['enable_otp']);
        }
    
        $settings['checkout_otp_message'] = $checkout_otp_message;
        $sms_balance = get_option('orderdetect_sms_balance');
        update_option('orderdetect_settings', $settings);
        wp_send_json_success(array('message' => 'OTP Settings Saved Successfully!') );

    }

    public function save_order_alerts() {
        check_ajax_referer('order-detect-admin-nonce', 'security');
    
        $settings = wp_parse_args(get_option('orderdetect_settings', array(
            'sms_provider' => 'greenweb',
            'sms_api_key' => array(
                'greenweb' => '',
                'alpha' => '',
                'dianahost' => ''
            ),
            'enable_otp' => 0,
            'checkout_otp_message' => '',
            'dianahost_sender_id' => '',
            'enable_invoice' => 0,
            'enable_packing_slip' => 0,
            'invoice_packing_slip_logo' => '',
            'business_name' => '',
            'enable_footer_text' => 0,
            'footer_text_heading' => '',
            'footer_text_details' => '',
            'delivery_partner' => '',
            'primary_color' => '#000'
        )));
        
        if (isset($_POST['settings']) && is_array($_POST['settings'])) {
            $new_settings = $_POST['settings'];
            
            foreach ($new_settings as $key => $value) {
                $settings[$key] = sanitize_text_field($value);
            }
        }
    
        update_option('orderdetect_settings', $settings);
    
        wp_send_json_success(array('message' => 'Settings Saved Successfully!'));
    }

    public function update_phone_number_status() {

        check_ajax_referer('order-detect-admin-nonce', 'security');
        $id = isset($_POST['id']) ? intval(wp_unslash($_POST['id'])) : 0;
        $is_verified = isset($_POST['is_verified']) ? intval(wp_unslash($_POST['is_verified'])) : 0;
        if( $id > 0 && is_numeric( $id ) && in_array($is_verified, [0, 1], true) ) {
            global $wpdb;
            $table_name = $wpdb->prefix . 'od_otp_log';
            $updated = $wpdb->update(
                $table_name,
                [ 'is_verified' => $is_verified ],
                [ 'id' => $id ],
                [ '%d' ],
                [ '%d' ]
            );
    
            if (false !== $updated) {
                wp_send_json_success([ 'message' => __('Status updated successfully.', 'order-detect') ]);
            } else {
                wp_send_json_error([ 'message' => __('Failed to update the status.', 'order-detect') ]);
            }
        } else {
            wp_send_json_error([ 'message' => __('Invalid ID or status value.', 'order-detect') ]);
        }
    }

    public function save_invoice_packing_slip_settings() {
        check_ajax_referer('order-detect-admin-nonce', 'security');

        $enable_invoice = isset($_POST['enable_invoice']) ? intval($_POST['enable_invoice']) : 0;
        // $enable_packing_slip = isset($_POST['enable_packing_slip']) ? intval($_POST['enable_packing_slip']) : 0;
        $logo = wp_unslash( $_POST['logo'] );
        // $business_name = wp_unslash( $_POST['business_name'] );
        $enable_footer_text = wp_unslash( $_POST['enable_footer_text'] );
        $footer_text_heading = wp_unslash( $_POST['footer_text_heading'] );
        $footer_text_details = wp_unslash( $_POST['footer_text_details'] );
        $delivery_partner = wp_unslash( $_POST['delivery_partner'] );
        $primary_color = wp_unslash( $_POST['primary_color'] );
    
        $settings = wp_parse_args(get_option('orderdetect_settings', array(
            'sms_provider' => 'greenweb',
            'sms_api_key' => array(
                'greenweb' => '',
                'alpha' => '',
                'dianahost' => ''
            ),
            'enable_otp' => 0,
            'checkout_otp_message' => '',
            'dianahost_sender_id' => '',
            'enable_invoice' => 0,
            'enable_packing_slip' => 0,
            'invoice_packing_slip_logo' => '',
            'business_name' => '',
            'enable_footer_text' => 0,
            'footer_text_heading' => '',
            'footer_text_details' => '',
            'delivery_partner' => '',
            'primary_color' => '#000'
        )));
    
        if ($logo) {
            $settings['invoice_packing_slip_logo'] = esc_url($logo);
        }

        $settings['enable_invoice'] = intval($enable_invoice);
        // $settings['enable_packing_slip'] = intval($enable_packing_slip);
        // $settings['business_name'] = $business_name;
        $settings['enable_footer_text'] = $enable_footer_text;
        $settings['footer_text_heading'] = $footer_text_heading;
        $settings['footer_text_details'] = $footer_text_details;
        $settings['delivery_partner'] = $delivery_partner;
        $settings['primary_color'] = $primary_color;

        update_option('orderdetect_settings', $settings);
        wp_send_json_success(array('message' => 'Invoice Settings Saved Successfully!') );

    }
    

}