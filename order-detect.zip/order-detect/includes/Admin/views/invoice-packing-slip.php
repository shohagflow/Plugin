<table class="od_invoice_metabox" style="width:100%;">			
    <tr>
        <td>
            <h4>
                <?php _e('Document details','order-detect'); ?>
            </h4>
            <span style="margin-top: 10px;display:block;">
                Invoice Id: <strong><?php echo $order_id; ?></strong>
            </span>
        </td>
    </tr>
    <tr>
        <td style="padding-bottom:10px;"></td>
    </tr>
    <tr>
        <td>
            <h4>
                <?php _e('Print','order-detect'); ?>
            </h4>
        </td>
    </tr>
    <tr>
        <td class="od_pklist_dash_btn_row">
            <div class="od_pklist_aggregate">
                <div class="od_pklist_btn_text">Invoice</div>
                <div class="od_pklist_aggregate_content">
                    <?php
                        $nonce = wp_create_nonce('order-detect');
                        $od_print_invoice = add_query_arg([
                        'print_od_packinglist' => 'true',
                        'post' => $order_id,
                        'type' => 'od_print_invoice',
                        '_wpnonce' => $nonce
                        ], admin_url());

                        // $od_download_invoice = add_query_arg([
                        // 'print_od_packinglist' => 'true',
                        // 'post' => $order_id,
                        // 'type' => 'od_download_invoice',
                        // '_wpnonce' => $nonce
                        // ], admin_url());
                        $tooltip_text = "Print Invoice";
                        $print_history = [];
                        $printed = "";
                        $print_history = get_post_meta( $order_id, 'print_history', true);
                        if( !empty($print_history) ){
                            $tooltip_text = "Already Printed";
                            $printed = "opacity:0.7;";
                        }
                    ?>
                    <a href="<?php echo esc_url($od_print_invoice); ?>" target="_blank" data-id="<?php echo esc_attr($order_id); ?>" class="od_pklist_admin_print_document_btn od-tooltip" title="<?php esc_attr_e('Print Invoice', 'order-detect'); ?>" data-prompt="0"> 
                        <span class="od-tooltiptext" style="bottom: 120%;left:30%;"><?php echo $tooltip_text; ?></span>
                        <span class="dashicons dashicons-printer" style="<?php echo $printed; ?>"></span>
                    </a>
                    <!-- <a href="<?php //echo esc_url($od_download_invoice); ?>" target="_blank" data-id="<?php echo esc_attr($order_id); ?>" class="od_pklist_admin_download_document_btn" title="Download Invoice" data-prompt="0"> 
                        <span class="dashicons dashicons-download"></span>
                    </a> -->
                </div>
            </div>
        </td>
    </tr>    
    <!-- <tr>
        <td class="od_pklist_dash_btn_row">
            <div class="od_pklist_aggregate">
                <div class="od_pklist_btn_text">Packing Slip</div>
                <div class="od_pklist_aggregate_content">
                    <?php
                        $nonce = wp_create_nonce('order-detect');
                        $print_packingslip = add_query_arg([
                        'print_od_packinglist' => 'true',
                        'post' => $order_id,
                        'type' => 'print_packingslip',
                        '_wpnonce' => $nonce
                        ], admin_url());

                        $download_packingslip = add_query_arg([
                        'print_od_packinglist' => 'true',
                        'post' => $order_id,
                        'type' => 'download_packingslip',
                        '_wpnonce' => $nonce
                        ], admin_url());
                    ?>
                    <a href="<?php echo esc_url($print_packingslip); ?>" target="_blank" data-id="<?php echo $order_id; ?>" class=" od_pklist_admin_print_document_btn" title="Print Invoice" data-prompt="0"> 
                        <span class="dashicons dashicons-printer"></span>
                    </a>
                    <a href="<?php echo esc_url($download_packingslip); ?>" target="_blank" data-id="<?php echo $order_id; ?>" class=" od_pklist_admin_download_document_btn" title="Download Invoice" data-prompt="0"> 
                        <span class="dashicons dashicons-download"></span>
                    </a>
                </div>
            </div>
        </td>
    </tr> -->
</table>
<?php 
    $print_history = get_post_meta( $order_id, 'print_history', true );
    if ( ! empty( $print_history ) && is_array( $print_history ) ): // Check if it's not empty and is an array
?>
    <table class="od_invoice_metabox" style="width:100%;">
        <tr>
            <td>
                <h4>
                    <?php _e('Print History','order-detect'); ?>
                </h4>
            </td>
        </tr>
        <tr>
            <td>
                <div class="table-container">
                    <table style="width:100%; border: 1px solid #efefef; border-collapse: collapse;">
                        <thead>
                            <tr>
                                <th style="border: 1px solid #efefef; padding: 8px;"><?php _e( 'User ID', 'order-detect' ); ?></th>
                                <th style="border: 1px solid #efefef; padding: 8px;"><?php _e( 'Time', 'order-detect' ); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ( $print_history as $entry ): ?>
                                <tr>
                                    <td style="border: 1px solid #efefef; padding: 8px;">
                                        <?php
                                            $user_info = get_userdata($entry['user_id']);
                                            if ($user_info) {
                                                echo esc_html($user_info->first_name . ' ' . $user_info->last_name);
                                                if (empty(trim($user_info->first_name . ' ' . $user_info->last_name))) {
                                                    echo esc_html($user_info->display_name);
                                                }
                                            } else {
                                                echo 'User not found';
                                            }
                                        ?>
                                    </td>
                                    <td style="border: 1px solid #efefef; padding: 8px;">
                                        <?php 
                                            $date = \DateTime::createFromFormat('Y-m-d H:i:s', $entry['time']);
                                            $date->setTimezone(new \DateTimeZone('Asia/Dhaka'));
                                            echo $date ? $date->format('F j, Y, g:i A') : __('N/A', 'order-detect');
                                        ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </td>
        </tr>
    </table>
<?php endif; ?>
