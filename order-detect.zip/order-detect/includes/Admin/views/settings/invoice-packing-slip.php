<div id="order-detect-order_invoice_packing_slip" class="order-detect-settings-tab">
    <div id="order-detect-settings-order_invoice_packing_slip" class="order-detect-settings-section order-detect-order_invoice_packing_slip">
        <table>
            <tbody>
                <tr data-id="delivery_partner" id="order-detect-meta-delivery_partner" class="order-detect-field order-detect-meta-checkbox type-checkbox">
                    <th class="order-detect-label">
                        <label for="delivery_partner">
                            Delivery Partner
                        </label>
                    </th>
                    <td class="order-detect-control">
                        <div class="order-detect-control-wrapper">
                            <select id="delivery_partner" name="orderdetect_settings[delivery_partner]">
                                <option value="">Select Delivery Partner</option>
                                <option value="SteadFast" <?php selected($delivery_partner, 'SteadFast'); ?>>SteadFast</option>
                                <option value="Pathao" <?php selected($delivery_partner, 'Pathao'); ?>>Pathao</option>
                                <option value="Redx" <?php selected($delivery_partner, 'Redx'); ?>>Redx</option>
                                <option value="Paperfly" <?php selected($delivery_partner, 'Paperfly'); ?>>Paperfly</option>
                            </select>
                        </div>
                    </td>
                </tr>
                <tr data-id="enable_invoice" id="order-detect-meta-enable_invoice" class="order-detect-field order-detect-meta-checkbox type-checkbox">
                    <th class="order-detect-label">
                        <label for="enable_invoice">
                            Invoice
                        </label>
                    </th>
                    <td class="order-detect-control">
                        <div class="order-detect-control-wrapper">
                            <label class="order-detect-switch">
                                <input class="order-detect-settings-field" 
                                    id="enable_invoice" 
                                    type="checkbox" 
                                    name="orderdetect_settings[enable_invoice]" 
                                    value="1" 
                                <?php checked( isset($enable_invoice) ? $enable_invoice : 0, 1 ); ?>>
                                <div class="slider"></div>
                            </label>
                        </div>
                    </td>
                </tr>
                <!-- <tr data-id="enable_packing_slip" id="order-detect-meta-enable_packing_slip" class="order-detect-field order-detect-meta-checkbox type-checkbox">
                    <th class="order-detect-label">
                        <label for="enable_packing_slip">
                            Packing Slip
                        </label>
                    </th>
                    <td class="order-detect-control">
                        <div class="order-detect-control-wrapper">
                            <label class="order-detect-switch">
                                <input class="order-detect-settings-field" 
                                    id="enable_packing_slip" 
                                    type="checkbox" 
                                    name="orderdetect_settings[enable_packing_slip]" 
                                    value="1" 
                                <?php //checked( isset($enable_packing_slip) ? $enable_packing_slip : 0, 1 ); ?>>
                                <div class="slider"></div>
                            </label>
                        </div>
                    </td>
                </tr> -->
                <tr data-id="order_invoice_packing_slip" id="order-detect-meta-order_invoice_packing_slip" class="order-detect-field order-detect-meta-text type-textarea ">
                    <th class="order-detect-label">
                        <label for="order_invoice_packing_slip">
                            Logo                                                         
                        </label>
                    </th>
                    <td class="order-detect-control">
                        <div class="order-detect-control-wrapper">
                            <div class="invoice-packing-slip-logo-area">
                                <img src="<?php echo esc_url( $invoice_packing_slip_logo ); ?>" id="invoice-packing-slip-logo" class="invoice-packing-slip-logo" alt="Invoice/packing slip logo" />
                            </div>
                            <button type="button" id="upload-invoice-packing-slip-logo" class="order-detect-settings-button"><span class="dashicons dashicons-upload"></span> Upload</button>
                            <p class="order-detect-field-help"></p>
                        </div>
                    </td>
                </tr>
                <!-- <tr data-id="business_name" id="order-detect-meta-business_name" class="order-detect-field order-detect-meta-textarea type-textarea ">
                    <th class="order-detect-label">
                        <label for="business_name">
                            Business Name                                                           
                        </label>
                    </th>
                    <td class="order-detect-control">
                        <div class="order-detect-control-wrapper">
                            <input type="text" name="business_name" id="business_name" class="order-detect-settings-field" placeholder="Business Name" value="<?php echo esc_attr( $business_name ); ?>">
                        </div>
                    </td>
                </tr> -->

                <tr data-id="primary_color" id="order-detect-meta-primary_color" class="order-detect-field">
                    <th class="order-detect-label">
                        <label for="primary_color">
                            Table Background Primary Color                                                           
                        </label>
                    </th>
                    <td class="order-detect-control">
                        <div class="order-detect-control-wrapper">
                            <input type="text" name="primary_color" id="primary_color" class="order-detect-settings-field od-color-field" value="<?php echo esc_attr( $primary_color ); ?>">
                        </div>
                    </td>
                </tr>
                
                <tr data-id="enable_footer_text" id="order-detect-meta-enable_footer_text" class="order-detect-field order-detect-meta-checkbox type-checkbox">
                    <th class="order-detect-label">
                        <label for="enable_footer_text">
                            Footer Text
                        </label>
                    </th>
                    <td class="order-detect-control">
                        <div class="order-detect-control-wrapper">
                            <label class="order-detect-switch">
                                <input class="order-detect-settings-field" 
                                    id="enable_footer_text" 
                                    type="checkbox" 
                                    name="orderdetect_settings[enable_footer_text]" 
                                    value="1" 
                                <?php checked( isset($enable_footer_text) ? $enable_footer_text : 0, 1 ); ?>>
                                <div class="slider"></div>
                            </label>
                        </div>
                    </td>
                </tr>
                <tr data-id="footer_text_heading" id="order-detect-meta-footer_text_heading" class="order-detect-field order-detect-meta-textarea type-textarea ">
                    <th class="order-detect-label">
                        <label for="footer_text_heading">
                            Footer Heading                                                           
                        </label>
                    </th>
                    <td class="order-detect-control">
                        <div class="order-detect-control-wrapper">
                            <input type="text" name="footer_text_heading" id="footer_text_heading" class="order-detect-settings-field" placeholder="Footer Text Heading" value="<?php echo esc_attr( $footer_text_heading ); ?>">
                        </div>
                    </td>
                </tr>
                <tr data-id="footer_text_details" id="order-detect-meta-footer_text_details" class="order-detect-field order-detect-meta-textarea type-textarea ">
                    <th class="order-detect-label">
                        <label for="footer_text_details">
                            Footer Message                                                            
                        </label>
                    </th>
                    <td class="order-detect-control">
                        <div class="order-detect-control-wrapper">
                            <?php
                                $content = isset( $footer_text_details ) ? $footer_text_details : '';
                                $editor_id = 'footer_text_details';
                                $settings = array(
                                    'textarea_name' => 'orderdetect_settings[footer_text_details]',
                                    'textarea_rows' => 2,
                                    'media_buttons' => false,
                                    'teeny' => true,
                                    'quicktags' => true,
                                    'editor_height' => 200,
                                );

                                wp_editor( $content, $editor_id, $settings );
                            ?>
                        </div>
                    </td>
                </tr>
            </tbody>
        </table>
        <p class="submit">
            <button type="button" name="invoice-packing-slip-save-btn" id="invoice-packing-slip-save-btn" class="btn-settings order-detect-settings-button">
                <span class="dashicons dashicons-cloud-saved"></span> Save
            </button>
        </p>
    </div>
</div>