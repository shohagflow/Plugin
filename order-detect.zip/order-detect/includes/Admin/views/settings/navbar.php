<div class="order-detect-settings-menu">
    <ul>
        <li class="order-detect-tab-nav-item" data-tab="license">
            <span>License</span>
        </li>

        <?php  if( $helper::check_license( wp_parse_args( get_option('orderdetect_license') ) ) ) { ?>
            <li class="order-detect-tab-nav-item" data-tab="provider_settings">
                <span> SMS Provider </span>
            </li>
        <?php } ?>

        <?php  if( $helper::check_license( wp_parse_args( get_option('orderdetect_license') ) ) ) { ?>
            <li class="order-detect-tab-nav-item" data-tab="otp_settings">
                <span> Checkout OTP </span>
            </li>
        <?php } ?>

        <?php  if( $helper::check_license( wp_parse_args( get_option('orderdetect_license') ) ) ) { ?>
            <li class="order-detect-tab-nav-item" data-tab="order_notifications">
                <span> Order Notification </span>
            </li>
        <?php } ?>

        <?php  if( $helper::check_license( wp_parse_args( get_option('orderdetect_license') ) ) ) { ?>
            <li class="order-detect-tab-nav-item" data-tab="order_invoice_packing_slip">
                <span> Invoice </span>
            </li>
        <?php } ?>              
    </ul>
</div>