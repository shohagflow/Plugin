<div id="order-detect-otp_settings" class="order-detect-settings-tab">
    <div id="order-detect-settings-otp_settings" class="order-detect-settings-section order-detect-otp_settings">
        <table>
            <tbody>
                <tr data-id="enable_otp" id="order-detect-meta-enable_otp" class="order-detect-field order-detect-meta-checkbox type-checkbox">
                    <th class="order-detect-label">
                        <label for="enable_otp">
                            Enable
                        </label>
                    </th>
                    <td class="order-detect-control">
                        <div class="order-detect-control-wrapper">
                            <label class="order-detect-switch">
                                <input class="order-detect-settings-field" 
                                    id="enable_otp" 
                                    type="checkbox" 
                                    name="orderdetect_settings[enable_otp]" 
                                    value="1" 
                                <?php checked( isset($enable_otp) ? $enable_otp : 0, 1 ); ?>>
                                <div class="slider"></div>
                            </label>
                        </div>
                    </td>
                </tr>
                <tr data-id="checkout_otp_message" id="order-detect-meta-checkout_otp_message" class="order-detect-field order-detect-meta-textarea type-textarea ">
                    <th class="order-detect-label">
                        <label for="checkout_otp_message">
                            Checkout OTP Message                                                            
                        </label>
                    </th>
                    <td class="order-detect-control">
                        <div class="order-detect-control-wrapper">
                            <textarea class="order-detect-settings-field" id="checkout_otp_message" name="orderdetect_settings[checkout_otp_message]" placeholder="Checkout OPT Message" rows="4" cols="20"><?php echo esc_attr( $checkout_otp_message ); ?></textarea>
                            <p class="order-detect-field-help">Example Format:
                                (Company Name)
                                আপনার ওটিপি: %otp_code%
                                @domain, #%otp_code%
                                Note: SMS Text এর শুরুতে অবশ্যই ব্রাকেট দিয়ে কোম্পানীর নাম/সাইট এড্রেস/ব্রান্ড নেম দিবেন, অনথ্যায় ওটিপি এসএমএস যাবে না। যেমনে, (Company Name) অথবা (কোম্পানীসাইট.কম)
                            </p>
                        </div>
                    </td>
                </tr>
            </tbody>
        </table>
        <p class="submit">
            <button type="button" name="otp-settings-save-btn" id="otp-settings-save-btn" class="btn-settings order-detect-settings-button">
                <span class="dashicons dashicons-cloud-saved"></span> Save
            </button>
        </p>
    </div>
</div>