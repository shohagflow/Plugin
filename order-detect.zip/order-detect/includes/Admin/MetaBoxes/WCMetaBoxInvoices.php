<?php

namespace OrderDetect\Admin\MetaBoxes;

use OrderDetect\Helper;

class WCMetaBoxInvoices
{

	public function __construct()
	{
		add_action( 'add_meta_boxes', array( $this, 'add_invoice_package_slip_meta_box' ) );
	}

	public function add_invoice_package_slip_meta_box() {

		$settings = wp_parse_args(get_option('orderdetect_settings', array(
			'sms_provider' => 'greenweb',
			'sms_api_key' => array(
				'greenweb' => '',
				'alpha' => '',
				'dianahost' => ''
			),
			'enable_otp' => 0,
			'checkout_otp_message' => '',
			'dianahost_sender_id' => '',
			'enable_invoice' => 0,
			'enable_packing_slip' => 0,
			'invoice_packing_slip_logo' => '',
			'business_name' => '',
			'enable_footer_text' => 0,
			'footer_text_heading' => '',
			'footer_text_details' => '',
            'delivery_partner' => '',
            'primary_color' => '#000'
		)));

		if( 1 === $settings['enable_invoice']  ) {
			$order_details_screen = Helper::is_wc_hpos_enabled() ? wc_get_page_screen_id( 'shop-order' ) : 'shop_order';
			add_meta_box(
				'orderdetect-invoice-package-slip',
				__('Invoice', 'order-detect'),
				array( $this, 'output' ),
				$order_details_screen,
				'side',
				'default'
			);
		}

	}

	/**
	 * Output the metabox.
	 *
	 * @param WP_Post|WC_Order $post Post or order object.
	 */
	public function output( $post_or_order_object ) {
		$order = ( $post_or_order_object instanceof \WP_Post ) ? wc_get_order( $post_or_order_object->ID ) : $post_or_order_object;
		if ( ! is_object( $order ) && is_numeric( $order ) ) {
			$order = wc_get_order( absint( $order ) );
		}
		$order_id = (WC()->version < '2.7.0') ? $order->id : $order->get_id();

		include_once  ORDERDETECT_PATH .'/includes/Admin/views/invoice-packing-slip.php';
	}
}