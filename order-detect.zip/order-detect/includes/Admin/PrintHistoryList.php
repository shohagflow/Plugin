<?php

namespace OrderDetect\Admin;

if (!class_exists('WP_List_Table')) {
    require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

class PrintHistoryList extends \WP_List_Table {

    private $search_term = '';

    public function __construct() {
        parent::__construct([
            'singular' => 'print_history',
            'plural'   => 'print_histories',
            'ajax'     => false,
        ]);

        $this->search_term = isset($_REQUEST['s']) ? sanitize_text_field($_REQUEST['s']) : '';
    }

    public function get_columns() {
        $columns = [
            'cb'          => '<input type="checkbox" />',
            'sl_no'       => __('SL No.', 'order-detect'),
            'order_id'    => __('Order ID', 'order-detect'),
            'print_by'    => __('Print By', 'order-detect'),
            'print_time'  => __('Print Time', 'order-detect'),
            'total_print' => __('Total Print', 'order-detect'),
        ];
        return $columns;
    }

    protected function column_default($item, $column_name) {
        switch ($column_name) {
            case 'sl_no':
                return $item['sl_no'];
            case 'order_id':
                $order_id = $item['order_id'];
                $order_url = $this->get_order_url($order_id);
                return sprintf('<a href="%s">#%s</a>', esc_url($order_url), esc_html($order_id));
            case 'print_by':
                return $item['print_by'];
            case 'print_time':
                return $item['print_time'];
            case 'total_print':
                return $item['total_print'];
            default:
                return print_r($item, true);
        }
    }

    protected function column_cb($item) {
        return sprintf('<input type="checkbox" name="print_history[]" value="%s" />', $item['order_id']);
    }

    public function get_bulk_actions() {
        $actions = [
            'delete' => __('Delete', 'order-detect'),
        ];
        return $actions;
    }

    public function process_bulk_action() {
        $ids = isset($_REQUEST['print_history']) ? $_REQUEST['print_history'] : [];
        if (is_array($ids)) {
            $ids = array_map('intval', $ids);
        }

        if (!empty($ids)) {
            if ('delete' === $this->current_action()) {
                $this->delete_items($ids);
            }
        }
    }

    private function delete_items($ids) {
        foreach ($ids as $order_id) {
            delete_post_meta($order_id, 'print_history');
        }
    }

    public function get_sortable_columns() {
        $sortable_columns = [
            'sl_no'       => ['sl_no', true],
            'order_id'    => ['order_id', false],
            'print_time'  => ['print_time', false],
            'total_print' => ['total_print', false],
        ];
        return $sortable_columns;
    }

    public function prepare_items() {
        $per_page = 20;
        $current_page = $this->get_pagenum();
        $total_items = $this->get_total_items();

        $this->set_pagination_args([
            'total_items' => $total_items,
            'per_page'    => $per_page,
            'total_pages' => ceil($total_items / $per_page),
        ]);

        $columns = $this->get_columns();
        $hidden = [];
        $sortable = $this->get_sortable_columns();
        $this->_column_headers = [$columns, $hidden, $sortable];

        $this->items = $this->get_print_history($per_page, $current_page);
    }

    public function get_total_items() {
        global $wpdb;
        $query = $this->build_query(['count' => true]);
        return $wpdb->get_var($query);
    }

    public function get_print_history($per_page, $page_number) {
        global $wpdb;
        $offset = ($page_number - 1) * $per_page;
        $query = $this->build_query(['limit' => $per_page, 'offset' => $offset]);
        $results = $wpdb->get_results($query, ARRAY_A);

        $print_history = [];
        $sl_no = ($page_number - 1) * $per_page + 1;

        foreach ($results as $result) {
            $order_id = $result['ID'];
            $history = get_post_meta($order_id, 'print_history', true);

            if (is_array($history) && !empty($history)) {
                $last_print = end($history);
                $print_history[] = [
                    'sl_no'       => $sl_no++,
                    'order_id'    => $order_id,
                    'print_by'    => $this->get_user_name($last_print['user_id']),
                    'print_time'  => $this->format_date($last_print['time']),
                    'total_print' => count($history),
                ];
            }
        }

        return $print_history;
    }
    
    private function build_query($args = []) {
        global $wpdb;
        $count = isset($args['count']) ? $args['count'] : false;
        $limit = isset($args['limit']) ? $args['limit'] : null;
        $offset = isset($args['offset']) ? $args['offset'] : 0;

        $select = $count ? "COUNT(DISTINCT p.ID)" : "DISTINCT p.ID, p.post_date";
        $query = "SELECT $select 
                  FROM {$wpdb->posts} p
                  INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
                  WHERE p.post_type IN ('shop_order', 'shop_order_placehold')
                  AND pm.meta_key = 'print_history'";

        if (!empty($this->search_term)) {
            if (is_numeric($this->search_term)) {
                $query .= $wpdb->prepare(" AND p.ID = %d", $this->search_term);
            } else {
                $query .= $wpdb->prepare(" AND p.ID IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_billing_first_name' AND meta_value LIKE %s)", '%' . $wpdb->esc_like($this->search_term) . '%');
                $query .= $wpdb->prepare(" OR p.ID IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_billing_last_name' AND meta_value LIKE %s)", '%' . $wpdb->esc_like($this->search_term) . '%');
            }
        }

        if (!$count) {
            $query .= " ORDER BY p.ID DESC";
            if ($limit) {
                $query .= $wpdb->prepare(" LIMIT %d OFFSET %d", $limit, $offset);
            }
        }

        return $query;
    }

    public function search_box($text, $input_id) {
        if (empty($this->search_term) && !$this->has_items()) {
            return;
        }

        $input_id = $input_id . '-search-input';
        ?>
        <p class="search-box">
            <label class="screen-reader-text" for="<?php echo esc_attr($input_id); ?>"><?php echo $text; ?>:</label>
            <input type="search" id="<?php echo esc_attr($input_id); ?>" name="s" value="<?php echo esc_attr($this->search_term); ?>" placeholder="<?php esc_attr_e('Search by Order ID', 'order-detect'); ?>" />
            <?php submit_button($text, '', '', false, ['id' => 'search-submit']); ?>
        </p>
        <?php
    }

    private function get_user_name($user_id) {
        $user = get_userdata($user_id);
        return $user ? $user->display_name : __('Unknown', 'order-detect');
    }

    private function format_date($date_string) {
        $date = \DateTime::createFromFormat('Y-m-d H:i:s', $date_string);
        return $date ? $date->format('F j, Y, g:i A') : __('N/A', 'order-detect');
    }
}