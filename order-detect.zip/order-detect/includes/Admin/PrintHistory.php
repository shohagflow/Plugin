<?php

namespace OrderDetect\Admin;

use OrderDetect\Admin\OTPLogList;
use OrderDetect\Helper;

class PrintHistory {

    public $main;

    public function __construct($main) {
        $this->main = $main;
        add_filter( 'orderdetect_admin_menu', array( $this, 'orderdetect_print_history' ), PHP_INT_MAX );
        add_filter( 'set-screen-option', array( $this, 'set_screen_option' ), 10, 3 );
        add_action( "load-order-detect_page_print-history", array( $this, 'add_screen_options' ) );
        // add_action( 'admin_post_export_print_logs', array( $this, 'export_print_logs' ) );

    }

    public function orderdetect_print_history( $settings ) {
        if( ! Helper::check_license( wp_parse_args( get_option('orderdetect_license') ) ) ) {
            return;
        }

        $settings['print-history']['parent_slug'] = 'order-detect';
        $settings['print-history']['page_title'] = __( 'Print History', 'order-detect' );
        $settings['print-history']['menu_title'] = __( 'Print History', 'order-detect' ); 
        $settings['print-history']['capability'] = 'manage_options'; 

        $phone_number = isset( $_GET['s'] ) ? sanitize_text_field( $_GET['s'] ) : '';
        $print_history = new PrintHistoryList( $phone_number );
        if( isset( $_GET['page'] ) && $_GET['page'] === 'print-history' ){
        	$print_history->prepare_items();
		}
        $settings['print-history']['callback'] = function () use ($print_history, $phone_number) {
            ?>
            <div class="wrap">
                <h1 class="wp-heading-inline"><?php echo __('Print History', 'order-detect'); ?></h1>
                <form method="get">
                    <input type="hidden" name="page" value="print-history" />
                    <?php
                        // $print_history->search_box(__('Search', 'order-detect'), 'order');
                        $print_history->search_box('Search Orders', 'order');
                        $print_history->views();
                        $print_history->display();
                    ?>
                </form>
            </div>
            <?php
        };

        return $settings;
    }

    public function set_screen_option($status, $option, $value) {
        if (in_array($option, array('print_log_per_page'), true)) {
            return $value;
        }

        return $status;
    }

    public function add_screen_options() {
        add_screen_option('per_page', array(
            'label'   => esc_html__('Number of items per page:', 'order-detect'),
            'default' => 20,
            'option'  => 'print_log_per_page',
        ));
    }

    public function export_print_logs() {
        if ( ! current_user_can('manage_options') ) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'order-detect'));
        }
    
        global $wpdb;
    
        $status = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : 'all';
        $table_name = $wpdb->prefix . 'od_otp_log';
    
        $query = "SELECT * FROM $table_name WHERE 1=1";
    
        if ($status === 'verified') {
            $query .= " AND is_verified = 1";
        } elseif ($status === 'unverified') {
            $query .= " AND is_verified = 0";
        }
    
        $sms_logs = $wpdb->get_results($query);
    
        // Set headers for Excel export
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment; filename="phone_number_logs_' . $status . '.xls"');
    
        // Output the data to Excel
        echo "ID\tPhone Number\tCode\tExpires At\tVerified?\tCreated At\n";
    
        foreach ($sms_logs as $log) {
            echo $log->id . "\t" . $log->phone_number . "\t" . $log->code . "\t" . $log->expires_at . "\t" . ($log->is_verified ? 'Yes' : 'No') . "\t" . $log->created_at . "\n";
        }
    
        exit; // Ensure no further output
    }
        
}
