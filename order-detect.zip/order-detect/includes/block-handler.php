<?php
use OrderDetect\Helper;
// Fraud ব্লকিং ফাংশন
function fraud_blocker_check_order() {
	if (! Helper::check_license(wp_parse_args(get_option('orderdetect_license')))) {
            return;
        }
    $customer_ip = $_SERVER['REMOTE_ADDR']; // কাস্টমারের আইপি ঠিকানা
    $phone_number = sanitize_text_field( $_POST['billing_phone'] ); // ফোন নাম্বার

    // ব্লক করা আইপি এবং ফোন নম্বরের তালিকা
    $blocked_ips = get_option( 'blocked_ips', [] );
    $blocked_phones = get_option( 'blocked_phones', [] );

    // যদি ব্লক করা আইপির তালিকায় থাকে
    if ( in_array( $customer_ip, $blocked_ips ) ) {
        wc_add_notice( 'আপনার অর্ডার ব্লক করা হয়েছে সন্দেহজনক কার্যকলাপের কারণে।', 'error' );
    }

    // যদি ব্লক করা ফোন নাম্বারের তালিকায় থাকে
    if ( in_array( $phone_number, $blocked_phones ) ) {
        wc_add_notice( 'আপনার ফোন নাম্বার ব্লক করা হয়েছে। অনুগ্রহ করে সঠিক তথ্য দিয়ে চেষ্টা করুন।', 'error' );
    }
}
add_action( 'woocommerce_checkout_process', 'fraud_blocker_check_order' );
